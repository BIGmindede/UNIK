/*
 * IP*Works! ZIP V9 C++ Edition - Demo Application
 *
 * Copyright (c) 2012 /n software inc. - All rights reserved. - www.nsoftware.com
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "include/ipworkszip.h"
#define LINE_LEN 100

typedef void* (IPWORKSZIP_CALL * _DLL_IP_ZIPCREATE)(PIPWORKSZIP_CALLBACK lpSink, void *lpContext, char *lpOemKey);
typedef int   (IPWORKSZIP_CALL * _DLL_IP_ZIPDESTROY)(void *lpObj);
typedef void* (IPWORKSZIP_CALL * _DLL_IP_ZIPGET)(void *lpObj, int propid, int arridx, int *lpcbVal);
typedef int   (IPWORKSZIP_CALL * _DLL_IP_ZIPSET)(void *lpObj, int propid, int arridx, const void *val, int cbVal);
typedef int   (IPWORKSZIP_CALL * _DLL_IP_ZIPDO)(void *lpObj, int methid, int cparam, void *param[], int cbparam[]);

static int IPWORKSZIP_CALL ZipEventSink(void* lpObj, int event_id, int cparam, void* param[], int cbparam[])
{
	return 0;
}

int ListDirectoryDLL(LPWSTR pszZipFileW)
{
	HINSTANCE hDLL = LoadLibrary(L"ipworkszip9.dll");

	if (hDLL == NULL)
		return GetLastError();

	_DLL_IP_ZIPCREATE  pfnZipCreate  = (_DLL_IP_ZIPCREATE)GetProcAddress(hDLL,  "IPWorksZip_Zip_Create");
	_DLL_IP_ZIPDESTROY pfnZipDestroy = (_DLL_IP_ZIPDESTROY)GetProcAddress(hDLL, "IPWorksZip_Zip_Destroy");
	_DLL_IP_ZIPGET     pfnZipGet     = (_DLL_IP_ZIPGET)GetProcAddress(hDLL,     "IPWorksZip_Zip_Get");
	_DLL_IP_ZIPSET     pfnZipSet     = (_DLL_IP_ZIPSET)GetProcAddress(hDLL,     "IPWorksZip_Zip_Set");
	_DLL_IP_ZIPDO      pfnZipDo      = (_DLL_IP_ZIPDO)GetProcAddress(hDLL,      "IPWorksZip_Zip_Do");

	if ((pfnZipCreate==NULL) || (pfnZipDestroy==NULL) || (pfnZipGet==NULL) || (pfnZipSet==NULL) || (pfnZipDo==NULL))
	{
		FreeLibrary(hDLL);

		return -1;
	}

	void* pObj = pfnZipCreate(ZipEventSink, (void *)0, (char*)IPWORKSZIP_OEMKEY_31);

	void *param[1+1]  = {(void*)(long)L"CodePage=65001", 0};
	int  cbparam[1+1] = {0, 0};
	
	// ************************** This is where it crashes for x64 builds **************************
	pfnZipDo(pObj, 10000+5, 1, param, cbparam);			// Config()

	int ret_code = pfnZipSet(pObj, 10000+1, 0, pszZipFileW, NULL);	// SetArchiveFile()

	if (!ret_code)
	{
		param[0] = 0;

		ret_code = pfnZipDo(pObj, 10000+11, 0, param, cbparam);	// Scan()
	}

	if (ret_code)
	{
		wprintf(L"Could not list %s: error %d\n", pszZipFileW, ret_code);
	}
	else
	{
		int nFiles = (int)pfnZipGet(pObj, 6, 0, 0);	// GetFileCount()

		wprintf(L"Contents of %s (using DLL entry points):\n\n", pszZipFileW);

		for (int i=0; i<nFiles; i++)
		{
			LPWSTR pszNameW = (LPWSTR)pfnZipGet(pObj, 10000+10, i, 0);		// GetFileCompressedName()
			
			wprintf(pszNameW);
			wprintf(L"\n");
		}
			
		wprintf(L"\n");
	}

	pfnZipDestroy(pObj);

	FreeLibrary(hDLL);

	return ret_code;
}

int ListDirectory(LPWSTR pszZipFileW)
{
	int   ret_code;
	ZipW* pZip = new ZipW;
	
	pZip->Config(L"CodePage=65001");	// UTF8

	ret_code = pZip->SetArchiveFile(pszZipFileW);

	if (!ret_code)
		ret_code = pZip->Scan();

	if (ret_code)
	{
		wprintf(L"Could not list %s: error %d\n", pszZipFileW, ret_code);
	}
	else
	{
		wprintf(L"Contents of %s:\n\n", pszZipFileW);
		for (int i=0; i < pZip->GetFileCount(); i++)
		{
			wprintf(pZip->GetFileCompressedName(i));
			wprintf(L"\n");
		}
			
		wprintf(L"\n");
	}

	delete pZip;

	return ret_code;
}

int main()
{
	ListDirectory(L"testfiles\\test.zip");

	ListDirectoryDLL(L"testfiles\\test.zip");

	fprintf(stderr, "\npress <return> to continue...\n");
	getchar();

	return 0;
}



