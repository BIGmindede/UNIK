/******************************************************************
   IP*Works! ZIP V9 C++ Edition
   Copyright (c) 2012 /n software inc. - All rights reserved.
*******************************************************************/

#ifndef _IPWORKSZIP_ZIP_H_
#define _IPWORKSZIP_ZIP_H_

#define IPWORKSZIP_ONLY_TYPES
#include "ipworkszip.h"
#include "ipworkszip.key"

//EncryptionAlgorithms
#define EA_DEFAULT                                         0
#define EA_AESWEAK                                         1
#define EA_AESSTRONG                                       2
#define EA_AESMAXIMUM                                      3


extern "C" void* IPWORKSZIP_CALL IPWorksZip_Zip_Create(PIPWORKSZIP_CALLBACK lpSink, void *lpContext, char *lpOemKey);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Zip_Destroy(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Zip_CheckIndex(void *lpObj, int propid, int arridx);
extern "C" void* IPWORKSZIP_CALL IPWorksZip_Zip_Get(void *lpObj, int propid, int arridx, int *lpcbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Zip_Set(void *lpObj, int propid, int arridx, const void *val, int cbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Zip_Do(void *lpObj, int methid, int cparam, void *param[], int cbparam[]);
extern "C" char* IPWORKSZIP_CALL IPWorksZip_Zip_GetLastError(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Zip_GetLastErrorCode(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Zip_StaticInit(void *hInst);

#ifdef WIN32
#include <windows.h>
#pragma warning(disable:4311) 
#pragma warning(disable:4312) 
#endif

typedef struct {
  int Index;
  int Skip;
  int reserved;
} ZipBeginFileEventParams;

typedef struct {
  int Index;
  int reserved;
} ZipEndFileEventParams;

typedef struct {
  const char* Description;
  int ErrorCode;
  int Index;
  const char* Filename;
  int Ignore;
  int reserved;
} ZipErrorEventParams;

typedef struct {
  const char* Filename;
  int Overwrite;
  int reserved;
} ZipOverwriteEventParams;

typedef struct {
  int Index;
  const char* Password;
  int reserved;
} ZipPasswordEventParams;

typedef struct {
  const char* Data;
  const char* Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int lenData;
  int reserved;
} ZipProgressEventParams;



class Zip {
  
  public: //events
  
    virtual int FireBeginFile(ZipBeginFileEventParams *e) {return 0;}
    virtual int FireEndFile(ZipEndFileEventParams *e) {return 0;}
    virtual int FireError(ZipErrorEventParams *e) {return 0;}
    virtual int FireOverwrite(ZipOverwriteEventParams *e) {return 0;}
    virtual int FirePassword(ZipPasswordEventParams *e) {return 0;}
    virtual int FireProgress(ZipProgressEventParams *e) {return 0;}


  protected:

    void *m_pObj;
    
    static int IPWORKSZIP_CALL ZipEventSink(void *lpObj, int event_id, int cparam, void *param[], int cbparam[]) {
      int ret_code = 0;
      if (event_id > 10000) return ((Zip*)lpObj)->ZipEventSinkW(event_id - 10000, cparam, param, cbparam);
      switch (event_id) {
         case 1: {
            ZipBeginFileEventParams e = {(int)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = ((Zip*)lpObj)->FireBeginFile(&e);
            param[1] = (void*)IPZ64CAST(e.Skip);
            break;
         }
         case 2: {
            ZipEndFileEventParams e = {(int)IPZ64CAST(param[0]),  0};
            ret_code = ((Zip*)lpObj)->FireEndFile(&e);
            break;
         }
         case 3: {
            ZipErrorEventParams e = {(char*)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]), (char*)IPZ64CAST(param[3]), (int)IPZ64CAST(param[4]),  0};
            ret_code = ((Zip*)lpObj)->FireError(&e);
            param[4] = (void*)IPZ64CAST(e.Ignore);
            break;
         }
         case 4: {
            ZipOverwriteEventParams e = {(char*)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = ((Zip*)lpObj)->FireOverwrite(&e);
            param[0] = (void*)IPZ64CAST(e.Filename);
            param[1] = (void*)IPZ64CAST(e.Overwrite);
            break;
         }
         case 5: {
            ZipPasswordEventParams e = {(int)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]),  0};
            ret_code = ((Zip*)lpObj)->FirePassword(&e);
            param[1] = (void*)IPZ64CAST(e.Password);
            break;
         }
         case 6: {
            ZipProgressEventParams e = {(char*)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]), (ns_int64*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = ((Zip*)lpObj)->FireProgress(&e);
            break;
         }

      }
      return ret_code;
    }

    virtual int ZipEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {return 0;}

  public:

    Zip(char *lpOemKey = (char*)IPWORKSZIP_OEMKEY_31) {
      m_pObj = IPWorksZip_Zip_Create(ZipEventSink, (void*)this, (char*)lpOemKey);
    }

    virtual ~Zip() {
      IPWorksZip_Zip_Destroy(m_pObj);
    }

  public:

    inline char *GetLastError() {
      return IPWorksZip_Zip_GetLastError(m_pObj);
    }
    
    inline int GetLastErrorCode() {
      return IPWorksZip_Zip_GetLastErrorCode(m_pObj);
    }

    inline char *VERSION() {
      return (char*)IPWorksZip_Zip_Get(m_pObj, 0, 0, 0);
    }

  public: //properties

    inline char* GetArchiveFile() {
      void* val = IPWorksZip_Zip_Get(m_pObj, 1, 0, 0);
      return (char*)val;
    }

    inline int SetArchiveFile(const char *lpArchiveFile) {
      return IPWorksZip_Zip_Set(m_pObj, 1, 0, (void*)lpArchiveFile, 0);
    }

    inline int GetCompressionLevel() {
      void* val = IPWorksZip_Zip_Get(m_pObj, 2, 0, 0);
      return (int)(long)val;
    }
    inline int SetCompressionLevel(int iCompressionLevel) {
      void* val = (void*)IPZ64CAST(iCompressionLevel);
      return IPWorksZip_Zip_Set(m_pObj, 2, 0, val, 0);
    }
    inline int GetEncryptionAlgorithm() {
      void* val = IPWorksZip_Zip_Get(m_pObj, 3, 0, 0);
      return (int)(long)val;
    }
    inline int SetEncryptionAlgorithm(int iEncryptionAlgorithm) {
      void* val = (void*)IPZ64CAST(iEncryptionAlgorithm);
      return IPWorksZip_Zip_Set(m_pObj, 3, 0, val, 0);
    }
    inline char* GetExcludedFiles() {
      void* val = IPWorksZip_Zip_Get(m_pObj, 4, 0, 0);
      return (char*)val;
    }

    inline int SetExcludedFiles(const char *lpExcludedFiles) {
      return IPWorksZip_Zip_Set(m_pObj, 4, 0, (void*)lpExcludedFiles, 0);
    }

    inline char* GetExtractToPath() {
      void* val = IPWorksZip_Zip_Get(m_pObj, 5, 0, 0);
      return (char*)val;
    }

    inline int SetExtractToPath(const char *lpExtractToPath) {
      return IPWorksZip_Zip_Set(m_pObj, 5, 0, (void*)lpExtractToPath, 0);
    }

    inline int GetFileCount() {
      void* val = IPWorksZip_Zip_Get(m_pObj, 6, 0, 0);
      return (int)(long)val;
    }
    inline int SetFileCount(int iFileCount) {
      void* val = (void*)IPZ64CAST(iFileCount);
      return IPWorksZip_Zip_Set(m_pObj, 6, 0, val, 0);
    }
    inline int GetFileAttributes(int iFileIndex) {
      void* val = IPWorksZip_Zip_Get(m_pObj, 7, iFileIndex, 0);
      return (int)(long)val;
    }
    inline int SetFileAttributes(int iFileIndex, int iFileAttributes) {
      void* val = (void*)IPZ64CAST(iFileAttributes);
      return IPWorksZip_Zip_Set(m_pObj, 7, iFileIndex, val, 0);
    }
    inline char* GetFileComment(int iFileIndex) {
      void* val = IPWorksZip_Zip_Get(m_pObj, 8, iFileIndex, 0);
      return (char*)val;
    }

    inline int SetFileComment(int iFileIndex, const char *lpFileComment) {
      return IPWorksZip_Zip_Set(m_pObj, 8, iFileIndex, (void*)lpFileComment, 0);
    }

    inline ns_int64 GetFileCompressedDate(int iFileIndex) {
      ns_int64 *pval = (ns_int64*)IPWorksZip_Zip_Get(m_pObj, 9, iFileIndex, 0);
      return *pval;
    }

    inline int SetFileCompressedDate(int iFileIndex, ns_int64 lFileCompressedDate) {
      void* val = (void*)(&lFileCompressedDate);
      return IPWorksZip_Zip_Set(m_pObj, 9, iFileIndex, val, 0);
    }

    inline char* GetFileCompressedName(int iFileIndex) {
      void* val = IPWorksZip_Zip_Get(m_pObj, 10, iFileIndex, 0);
      return (char*)val;
    }

    inline int SetFileCompressedName(int iFileIndex, const char *lpFileCompressedName) {
      return IPWorksZip_Zip_Set(m_pObj, 10, iFileIndex, (void*)lpFileCompressedName, 0);
    }

    inline ns_int64 GetFileCompressedSize(int iFileIndex) {
      ns_int64 *pval = (ns_int64*)IPWorksZip_Zip_Get(m_pObj, 11, iFileIndex, 0);
      return *pval;
    }


    inline ns_int64 GetFileCRC(int iFileIndex) {
      ns_int64 *pval = (ns_int64*)IPWorksZip_Zip_Get(m_pObj, 12, iFileIndex, 0);
      return *pval;
    }


    inline char* GetFileDecompressedName(int iFileIndex) {
      void* val = IPWorksZip_Zip_Get(m_pObj, 13, iFileIndex, 0);
      return (char*)val;
    }

    inline int SetFileDecompressedName(int iFileIndex, const char *lpFileDecompressedName) {
      return IPWorksZip_Zip_Set(m_pObj, 13, iFileIndex, (void*)lpFileDecompressedName, 0);
    }

    inline ns_int64 GetFileDecompressedSize(int iFileIndex) {
      ns_int64 *pval = (ns_int64*)IPWorksZip_Zip_Get(m_pObj, 14, iFileIndex, 0);
      return *pval;
    }


    inline int GetFileEncryptionAlgorithm(int iFileIndex) {
      void* val = IPWorksZip_Zip_Get(m_pObj, 15, iFileIndex, 0);
      return (int)(long)val;
    }
    inline int SetFileEncryptionAlgorithm(int iFileIndex, int iFileEncryptionAlgorithm) {
      void* val = (void*)IPZ64CAST(iFileEncryptionAlgorithm);
      return IPWorksZip_Zip_Set(m_pObj, 15, iFileIndex, val, 0);
    }
    inline char* GetFilePassword(int iFileIndex) {
      void* val = IPWorksZip_Zip_Get(m_pObj, 16, iFileIndex, 0);
      return (char*)val;
    }

    inline int SetFilePassword(int iFileIndex, const char *lpFilePassword) {
      return IPWorksZip_Zip_Set(m_pObj, 16, iFileIndex, (void*)lpFilePassword, 0);
    }

    inline int GetFilePasswordRequired(int iFileIndex) {
      void* val = IPWorksZip_Zip_Get(m_pObj, 17, iFileIndex, 0);
      return (int)(long)val;
    }

    inline int GetOverwriteFiles() {
      void* val = IPWorksZip_Zip_Get(m_pObj, 18, 0, 0);
      return (int)(long)val;
    }
    inline int SetOverwriteFiles(int bOverwriteFiles) {
      void* val = (void*)IPZ64CAST(bOverwriteFiles);
      return IPWorksZip_Zip_Set(m_pObj, 18, 0, val, 0);
    }
    inline char* GetPassword() {
      void* val = IPWorksZip_Zip_Get(m_pObj, 19, 0, 0);
      return (char*)val;
    }

    inline int SetPassword(const char *lpPassword) {
      return IPWorksZip_Zip_Set(m_pObj, 19, 0, (void*)lpPassword, 0);
    }

    inline int GetRecurseSubdirectories() {
      void* val = IPWorksZip_Zip_Get(m_pObj, 20, 0, 0);
      return (int)(long)val;
    }
    inline int SetRecurseSubdirectories(int bRecurseSubdirectories) {
      void* val = (void*)IPZ64CAST(bRecurseSubdirectories);
      return IPWorksZip_Zip_Set(m_pObj, 20, 0, val, 0);
    }
    inline char* GetZipComment() {
      void* val = IPWorksZip_Zip_Get(m_pObj, 21, 0, 0);
      return (char*)val;
    }

    inline int SetZipComment(const char *lpZipComment) {
      return IPWorksZip_Zip_Set(m_pObj, 21, 0, (void*)lpZipComment, 0);
    }


    inline int SetZipData(const char *lpZipData, int lenZipData) {
      return IPWorksZip_Zip_Set(m_pObj, 22, 0, (void*)lpZipData, lenZipData);
    }


  public: //methods

    inline int Abort() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 2, 0, param, cbparam);
      
      
    }
    inline int AppendFiles() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 3, 0, param, cbparam);
      
      
    }
    inline int Compress() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 4, 0, param, cbparam);
      
      
    }
    inline char* Config(const char* lpszConfigurationString) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszConfigurationString), 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_Zip_Do(m_pObj, 5, 1, param, cbparam);
      
      return (char*)param[1];
    }
    inline int Delete(const char* lpszFilenames) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszFilenames), 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Zip_Do(m_pObj, 6, 1, param, cbparam);
      
      
    }
    inline int Extract(const char* lpszFilenames) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszFilenames), 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Zip_Do(m_pObj, 7, 1, param, cbparam);
      
      
    }
    inline int ExtractAll() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 8, 0, param, cbparam);
      
      
    }
    inline int IncludeFiles(const char* lpszfilenames) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszfilenames), 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Zip_Do(m_pObj, 9, 1, param, cbparam);
      
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 10, 0, param, cbparam);
      
      
    }
    inline int Scan() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 11, 0, param, cbparam);
      
      
    }
    inline int Update(const char* lpszFilenames) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszFilenames), 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Zip_Do(m_pObj, 14, 1, param, cbparam);
      
      
    }

};


#ifdef WIN32 //UNICODE

typedef struct {
  int Index;
  int Skip;
  int reserved;
} ZipBeginFileEventParamsW;

typedef struct {
  int Index;
  int reserved;
} ZipEndFileEventParamsW;

typedef struct {
  LPWSTR Description;
  int ErrorCode;
  int Index;
  LPWSTR Filename;
  int Ignore;
  int reserved;
} ZipErrorEventParamsW;

typedef struct {
  LPWSTR Filename;
  int Overwrite;
  int reserved;
} ZipOverwriteEventParamsW;

typedef struct {
  int Index;
  LPWSTR Password;
  int reserved;
} ZipPasswordEventParamsW;

typedef struct {
  LPWSTR Data;
  LPWSTR Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int lenData;
  int reserved;
} ZipProgressEventParamsW;



class ZipW : public Zip {

  public: //properties
  
    inline LPWSTR GetArchiveFile() {
      return (LPWSTR)IPWorksZip_Zip_Get(m_pObj, 10000+1, 0, 0);
    }

    inline int SetArchiveFile(LPWSTR lpArchiveFile) {
      return IPWorksZip_Zip_Set(m_pObj, 10000+1, 0, (void*)lpArchiveFile, 0);
    }





    inline LPWSTR GetExcludedFiles() {
      return (LPWSTR)IPWorksZip_Zip_Get(m_pObj, 10000+4, 0, 0);
    }

    inline int SetExcludedFiles(LPWSTR lpExcludedFiles) {
      return IPWorksZip_Zip_Set(m_pObj, 10000+4, 0, (void*)lpExcludedFiles, 0);
    }

    inline LPWSTR GetExtractToPath() {
      return (LPWSTR)IPWorksZip_Zip_Get(m_pObj, 10000+5, 0, 0);
    }

    inline int SetExtractToPath(LPWSTR lpExtractToPath) {
      return IPWorksZip_Zip_Set(m_pObj, 10000+5, 0, (void*)lpExtractToPath, 0);
    }





    inline LPWSTR GetFileComment(int iFileIndex) {
      return (LPWSTR)IPWorksZip_Zip_Get(m_pObj, 10000+8, iFileIndex, 0);
    }

    inline int SetFileComment(int iFileIndex, LPWSTR lpFileComment) {
      return IPWorksZip_Zip_Set(m_pObj, 10000+8, iFileIndex, (void*)lpFileComment, 0);
    }



    inline LPWSTR GetFileCompressedName(int iFileIndex) {
      return (LPWSTR)IPWorksZip_Zip_Get(m_pObj, 10000+10, iFileIndex, 0);
    }

    inline int SetFileCompressedName(int iFileIndex, LPWSTR lpFileCompressedName) {
      return IPWorksZip_Zip_Set(m_pObj, 10000+10, iFileIndex, (void*)lpFileCompressedName, 0);
    }





    inline LPWSTR GetFileDecompressedName(int iFileIndex) {
      return (LPWSTR)IPWorksZip_Zip_Get(m_pObj, 10000+13, iFileIndex, 0);
    }

    inline int SetFileDecompressedName(int iFileIndex, LPWSTR lpFileDecompressedName) {
      return IPWorksZip_Zip_Set(m_pObj, 10000+13, iFileIndex, (void*)lpFileDecompressedName, 0);
    }





    inline LPWSTR GetFilePassword(int iFileIndex) {
      return (LPWSTR)IPWorksZip_Zip_Get(m_pObj, 10000+16, iFileIndex, 0);
    }

    inline int SetFilePassword(int iFileIndex, LPWSTR lpFilePassword) {
      return IPWorksZip_Zip_Set(m_pObj, 10000+16, iFileIndex, (void*)lpFilePassword, 0);
    }





    inline LPWSTR GetPassword() {
      return (LPWSTR)IPWorksZip_Zip_Get(m_pObj, 10000+19, 0, 0);
    }

    inline int SetPassword(LPWSTR lpPassword) {
      return IPWorksZip_Zip_Set(m_pObj, 10000+19, 0, (void*)lpPassword, 0);
    }



    inline LPWSTR GetZipComment() {
      return (LPWSTR)IPWorksZip_Zip_Get(m_pObj, 10000+21, 0, 0);
    }

    inline int SetZipComment(LPWSTR lpZipComment) {
      return IPWorksZip_Zip_Set(m_pObj, 10000+21, 0, (void*)lpZipComment, 0);
    }



    inline int SetZipData(LPWSTR lpZipData) {
      return IPWorksZip_Zip_Set(m_pObj, 10000+22, 0, (void*)lpZipData, 0);
    }

    inline int SetZipDataB(const char *lpZipData, int lenZipData) {
      return IPWorksZip_Zip_Set(m_pObj, 22, 0, (void*)lpZipData, lenZipData);
    }


  public: //events
  
    virtual int FireBeginFile(ZipBeginFileEventParamsW *e) {return 0;}
    virtual int FireEndFile(ZipEndFileEventParamsW *e) {return 0;}
    virtual int FireError(ZipErrorEventParamsW *e) {return 0;}
    virtual int FireOverwrite(ZipOverwriteEventParamsW *e) {return 0;}
    virtual int FirePassword(ZipPasswordEventParamsW *e) {return 0;}
    virtual int FireProgress(ZipProgressEventParamsW *e) {return 0;}


  protected:
  
    virtual int ZipEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {
    	int ret_code = 0;
      switch (event_id) {
         case 1: {
            ZipBeginFileEventParamsW e = {(int)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = FireBeginFile(&e);
            param[1] = (void*)(e.Skip);
            break;
         }
         case 2: {
            ZipEndFileEventParamsW e = {(int)IPZ64CAST(param[0]),  0};
            ret_code = FireEndFile(&e);
            break;
         }
         case 3: {
            ZipErrorEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]), (LPWSTR)IPZ64CAST(param[3]), (int)IPZ64CAST(param[4]),  0};
            ret_code = FireError(&e);
            param[4] = (void*)(e.Ignore);
            break;
         }
         case 4: {
            ZipOverwriteEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = FireOverwrite(&e);
            param[0] = (void*)(e.Filename);
            param[1] = (void*)(e.Overwrite);
            break;
         }
         case 5: {
            ZipPasswordEventParamsW e = {(int)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]),  0};
            ret_code = FirePassword(&e);
            param[1] = (void*)(e.Password);
            break;
         }
         case 6: {
            ZipProgressEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]), (ns_int64*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = FireProgress(&e);
            break;
         }

      }
      return ret_code;
    }
  
  public: //event overrides

    virtual int FireBeginFile(ZipBeginFileEventParams *e) {return -10000;}
    virtual int FireEndFile(ZipEndFileEventParams *e) {return -10000;}
    virtual int FireError(ZipErrorEventParams *e) {return -10000;}
    virtual int FireOverwrite(ZipOverwriteEventParams *e) {return -10000;}
    virtual int FirePassword(ZipPasswordEventParams *e) {return -10000;}
    virtual int FireProgress(ZipProgressEventParams *e) {return -10000;}

  public: //methods

    inline int Abort() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 10000+2, 0, param, cbparam);
      
    }
    inline int AppendFiles() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 10000+3, 0, param, cbparam);
      
    }
    inline int Compress() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 10000+4, 0, param, cbparam);
      
    }
    inline LPWSTR Config(LPWSTR lpszConfigurationString) {
      void *param[1+1] = {(void*)lpszConfigurationString, 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_Zip_Do(m_pObj, 10000+5, 1, param, cbparam);
      return (LPWSTR)param[1];
    }
    inline int Delete(LPWSTR lpszFilenames) {
      void *param[1+1] = {(void*)lpszFilenames, 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Zip_Do(m_pObj, 10000+6, 1, param, cbparam);
      
    }
    inline int Extract(LPWSTR lpszFilenames) {
      void *param[1+1] = {(void*)lpszFilenames, 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Zip_Do(m_pObj, 10000+7, 1, param, cbparam);
      
    }
    inline int ExtractAll() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 10000+8, 0, param, cbparam);
      
    }
    inline int IncludeFiles(LPWSTR lpszfilenames) {
      void *param[1+1] = {(void*)lpszfilenames, 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Zip_Do(m_pObj, 10000+9, 1, param, cbparam);
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 10000+10, 0, param, cbparam);
      
    }
    inline int Scan() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Zip_Do(m_pObj, 10000+11, 0, param, cbparam);
      
    }
    inline int Update(LPWSTR lpszFilenames) {
      void *param[1+1] = {(void*)lpszFilenames, 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Zip_Do(m_pObj, 10000+14, 1, param, cbparam);
      
    }

};

#endif //WIN32

#endif //_IPWORKSZIP_ZIP_H_




