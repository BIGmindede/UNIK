/******************************************************************
   IP*Works! ZIP V9 C++ Edition
   Copyright (c) 2012 /n software inc. - All rights reserved.
*******************************************************************/

#ifndef _IPWORKSZIP_OFFICEDOC_H_
#define _IPWORKSZIP_OFFICEDOC_H_

#define IPWORKSZIP_ONLY_TYPES
#include "ipworkszip.h"
#include "ipworkszip.key"


extern "C" void* IPWORKSZIP_CALL IPWorksZip_OfficeDoc_Create(PIPWORKSZIP_CALLBACK lpSink, void *lpContext, char *lpOemKey);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_OfficeDoc_Destroy(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_OfficeDoc_CheckIndex(void *lpObj, int propid, int arridx);
extern "C" void* IPWORKSZIP_CALL IPWorksZip_OfficeDoc_Get(void *lpObj, int propid, int arridx, int *lpcbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_OfficeDoc_Set(void *lpObj, int propid, int arridx, const void *val, int cbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_OfficeDoc_Do(void *lpObj, int methid, int cparam, void *param[], int cbparam[]);
extern "C" char* IPWORKSZIP_CALL IPWorksZip_OfficeDoc_GetLastError(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_OfficeDoc_GetLastErrorCode(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_OfficeDoc_StaticInit(void *hInst);

#ifdef WIN32
#include <windows.h>
#pragma warning(disable:4311) 
#pragma warning(disable:4312) 
#endif

typedef struct {
  int Index;
  int Skip;
  int reserved;
} OfficeDocBeginFileEventParams;

typedef struct {
  const char* Text;
  int lenText;
  int reserved;
} OfficeDocCharactersEventParams;

typedef struct {
  const char* Text;
  int reserved;
} OfficeDocCommentEventParams;

typedef struct {
  const char* Namespace;
  const char* Element;
  const char* QName;
  int IsEmpty;
  int reserved;
} OfficeDocEndElementEventParams;

typedef struct {
  int Index;
  int reserved;
} OfficeDocEndFileEventParams;

typedef struct {
  const char* Prefix;
  int reserved;
} OfficeDocEndPrefixMappingEventParams;

typedef struct {
  int ErrorCode;
  const char* Description;
  int reserved;
} OfficeDocErrorEventParams;

typedef struct {
  const char* Entity;
  const char* Value;
  int reserved;
} OfficeDocEvalEntityEventParams;

typedef struct {
  const char* Text;
  int reserved;
} OfficeDocIgnorableWhitespaceEventParams;

typedef struct {
  const char* Text;
  int reserved;
} OfficeDocMetaEventParams;

typedef struct {
  const char* Filename;
  int Overwrite;
  int reserved;
} OfficeDocOverwriteEventParams;

typedef struct {
  const char* Text;
  int reserved;
} OfficeDocPIEventParams;

typedef struct {
  const char* Data;
  const char* Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int lenData;
  int reserved;
} OfficeDocProgressEventParams;

typedef struct {
  const char* SectionId;
  const char* Text;
  int reserved;
} OfficeDocSpecialSectionEventParams;

typedef struct {
  const char* Namespace;
  const char* Element;
  const char* QName;
  int IsEmpty;
  int reserved;
} OfficeDocStartElementEventParams;

typedef struct {
  const char* Prefix;
  const char* URI;
  int reserved;
} OfficeDocStartPrefixMappingEventParams;



class OfficeDoc {
  
  public: //events
  
    virtual int FireBeginFile(OfficeDocBeginFileEventParams *e) {return 0;}
    virtual int FireCharacters(OfficeDocCharactersEventParams *e) {return 0;}
    virtual int FireComment(OfficeDocCommentEventParams *e) {return 0;}
    virtual int FireEndElement(OfficeDocEndElementEventParams *e) {return 0;}
    virtual int FireEndFile(OfficeDocEndFileEventParams *e) {return 0;}
    virtual int FireEndPrefixMapping(OfficeDocEndPrefixMappingEventParams *e) {return 0;}
    virtual int FireError(OfficeDocErrorEventParams *e) {return 0;}
    virtual int FireEvalEntity(OfficeDocEvalEntityEventParams *e) {return 0;}
    virtual int FireIgnorableWhitespace(OfficeDocIgnorableWhitespaceEventParams *e) {return 0;}
    virtual int FireMeta(OfficeDocMetaEventParams *e) {return 0;}
    virtual int FireOverwrite(OfficeDocOverwriteEventParams *e) {return 0;}
    virtual int FirePI(OfficeDocPIEventParams *e) {return 0;}
    virtual int FireProgress(OfficeDocProgressEventParams *e) {return 0;}
    virtual int FireSpecialSection(OfficeDocSpecialSectionEventParams *e) {return 0;}
    virtual int FireStartElement(OfficeDocStartElementEventParams *e) {return 0;}
    virtual int FireStartPrefixMapping(OfficeDocStartPrefixMappingEventParams *e) {return 0;}


  protected:

    void *m_pObj;
    
    static int IPWORKSZIP_CALL OfficeDocEventSink(void *lpObj, int event_id, int cparam, void *param[], int cbparam[]) {
      int ret_code = 0;
      if (event_id > 10000) return ((OfficeDoc*)lpObj)->OfficeDocEventSinkW(event_id - 10000, cparam, param, cbparam);
      switch (event_id) {
         case 1: {
            OfficeDocBeginFileEventParams e = {(int)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireBeginFile(&e);
            param[1] = (void*)IPZ64CAST(e.Skip);
            break;
         }
         case 2: {
            OfficeDocCharactersEventParams e = {(char*)IPZ64CAST(param[0]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireCharacters(&e);
            break;
         }
         case 3: {
            OfficeDocCommentEventParams e = {(char*)IPZ64CAST(param[0]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireComment(&e);
            break;
         }
         case 4: {
            OfficeDocEndElementEventParams e = {(char*)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]), (char*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireEndElement(&e);
            break;
         }
         case 5: {
            OfficeDocEndFileEventParams e = {(int)IPZ64CAST(param[0]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireEndFile(&e);
            break;
         }
         case 6: {
            OfficeDocEndPrefixMappingEventParams e = {(char*)IPZ64CAST(param[0]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireEndPrefixMapping(&e);
            break;
         }
         case 7: {
            OfficeDocErrorEventParams e = {(int)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireError(&e);
            break;
         }
         case 8: {
            OfficeDocEvalEntityEventParams e = {(char*)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireEvalEntity(&e);
            param[1] = (void*)IPZ64CAST(e.Value);
            break;
         }
         case 9: {
            OfficeDocIgnorableWhitespaceEventParams e = {(char*)IPZ64CAST(param[0]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireIgnorableWhitespace(&e);
            break;
         }
         case 10: {
            OfficeDocMetaEventParams e = {(char*)IPZ64CAST(param[0]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireMeta(&e);
            break;
         }
         case 11: {
            OfficeDocOverwriteEventParams e = {(char*)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireOverwrite(&e);
            param[0] = (void*)IPZ64CAST(e.Filename);
            param[1] = (void*)IPZ64CAST(e.Overwrite);
            break;
         }
         case 12: {
            OfficeDocPIEventParams e = {(char*)IPZ64CAST(param[0]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FirePI(&e);
            break;
         }
         case 13: {
            OfficeDocProgressEventParams e = {(char*)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]), (ns_int64*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireProgress(&e);
            break;
         }
         case 14: {
            OfficeDocSpecialSectionEventParams e = {(char*)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireSpecialSection(&e);
            break;
         }
         case 15: {
            OfficeDocStartElementEventParams e = {(char*)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]), (char*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireStartElement(&e);
            break;
         }
         case 16: {
            OfficeDocStartPrefixMappingEventParams e = {(char*)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]),  0};
            ret_code = ((OfficeDoc*)lpObj)->FireStartPrefixMapping(&e);
            break;
         }

      }
      return ret_code;
    }

    virtual int OfficeDocEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {return 0;}

  public:

    OfficeDoc(char *lpOemKey = (char*)IPWORKSZIP_OEMKEY_41) {
      m_pObj = IPWorksZip_OfficeDoc_Create(OfficeDocEventSink, (void*)this, (char*)lpOemKey);
    }

    virtual ~OfficeDoc() {
      IPWorksZip_OfficeDoc_Destroy(m_pObj);
    }

  public:

    inline char *GetLastError() {
      return IPWorksZip_OfficeDoc_GetLastError(m_pObj);
    }
    
    inline int GetLastErrorCode() {
      return IPWorksZip_OfficeDoc_GetLastErrorCode(m_pObj);
    }

    inline char *VERSION() {
      return (char*)IPWorksZip_OfficeDoc_Get(m_pObj, 0, 0, 0);
    }

  public: //properties

    inline int GetContentTypeCount() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 1, 0, 0);
      return (int)(long)val;
    }

    inline int GetContentTypeIsOverride(int iContentTypeIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 2, iContentTypeIndex, 0);
      return (int)(long)val;
    }

    inline char* GetContentTypeMediaType(int iContentTypeIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 3, iContentTypeIndex, 0);
      return (char*)val;
    }


    inline char* GetContentTypeTarget(int iContentTypeIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 4, iContentTypeIndex, 0);
      return (char*)val;
    }


    inline int GetNamespaceCount() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 5, 0, 0);
      return (int)(long)val;
    }

    inline char* GetNamespacePrefix(int iNamespaceIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 6, iNamespaceIndex, 0);
      return (char*)val;
    }


    inline char* GetNamespaceURI(int iNamespaceIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 7, iNamespaceIndex, 0);
      return (char*)val;
    }


    inline char* GetPackagePath() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 8, 0, 0);
      return (char*)val;
    }

    inline int SetPackagePath(const char *lpPackagePath) {
      return IPWorksZip_OfficeDoc_Set(m_pObj, 8, 0, (void*)lpPackagePath, 0);
    }

    inline int GetPackagePropertyCount() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 9, 0, 0);
      return (int)(long)val;
    }

    inline char* GetPackagePropertyDataType(int iPackagePropertyIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 10, iPackagePropertyIndex, 0);
      return (char*)val;
    }


    inline char* GetPackagePropertyName(int iPackagePropertyIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 11, iPackagePropertyIndex, 0);
      return (char*)val;
    }


    inline char* GetPackagePropertyNamespace(int iPackagePropertyIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 12, iPackagePropertyIndex, 0);
      return (char*)val;
    }


    inline char* GetPackagePropertyPropId(int iPackagePropertyIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 13, iPackagePropertyIndex, 0);
      return (char*)val;
    }


    inline char* GetPackagePropertyPropSet(int iPackagePropertyIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 14, iPackagePropertyIndex, 0);
      return (char*)val;
    }


    inline char* GetPackagePropertyValue(int iPackagePropertyIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 15, iPackagePropertyIndex, 0);
      return (char*)val;
    }


    inline int GetPartData(char *&lpPartData, int &lenPartData) {
      lpPartData = (char*)IPWorksZip_OfficeDoc_Get(m_pObj, 16, 0, &lenPartData);
      return lpPartData ? 0 : lenPartData;
    }

    inline int SetPartData(const char *lpPartData, int lenPartData) {
      return IPWorksZip_OfficeDoc_Set(m_pObj, 16, 0, (void*)lpPartData, lenPartData);
    }

    inline char* GetPartName() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 17, 0, 0);
      return (char*)val;
    }

    inline int SetPartName(const char *lpPartName) {
      return IPWorksZip_OfficeDoc_Set(m_pObj, 17, 0, (void*)lpPartName, 0);
    }

    inline int GetRelationshipCount() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 18, 0, 0);
      return (int)(long)val;
    }

    inline char* GetRelationshipContentType(int iRelationshipIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 19, iRelationshipIndex, 0);
      return (char*)val;
    }


    inline char* GetRelationshipId(int iRelationshipIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 20, iRelationshipIndex, 0);
      return (char*)val;
    }


    inline char* GetRelationshipPartName(int iRelationshipIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 21, iRelationshipIndex, 0);
      return (char*)val;
    }


    inline char* GetRelationshipTypeURI(int iRelationshipIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 22, iRelationshipIndex, 0);
      return (char*)val;
    }


    inline int GetValidate() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 23, 0, 0);
      return (int)(long)val;
    }
    inline int SetValidate(int bValidate) {
      void* val = (void*)IPZ64CAST(bValidate);
      return IPWorksZip_OfficeDoc_Set(m_pObj, 23, 0, val, 0);
    }
    inline int GetAttrCount() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 24, 0, 0);
      return (int)(long)val;
    }

    inline char* GetAttrName(int iAttrIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 25, iAttrIndex, 0);
      return (char*)val;
    }


    inline char* GetAttrNamespace(int iAttrIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 26, iAttrIndex, 0);
      return (char*)val;
    }


    inline char* GetAttrPrefix(int iAttrIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 27, iAttrIndex, 0);
      return (char*)val;
    }


    inline char* GetAttrValue(int iAttrIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 28, iAttrIndex, 0);
      return (char*)val;
    }


    inline int GetXChildrenCount() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 29, 0, 0);
      return (int)(long)val;
    }

    inline char* GetXChildName(int iXChildIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 30, iXChildIndex, 0);
      return (char*)val;
    }


    inline char* GetXChildNamespace(int iXChildIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 31, iXChildIndex, 0);
      return (char*)val;
    }


    inline char* GetXChildPrefix(int iXChildIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 32, iXChildIndex, 0);
      return (char*)val;
    }


    inline char* GetXChildXText(int iXChildIndex) {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 33, iXChildIndex, 0);
      return (char*)val;
    }


    inline char* GetXElement() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 34, 0, 0);
      return (char*)val;
    }


    inline char* GetXNamespace() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 35, 0, 0);
      return (char*)val;
    }


    inline char* GetXParent() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 36, 0, 0);
      return (char*)val;
    }


    inline char* GetXPath() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 37, 0, 0);
      return (char*)val;
    }

    inline int SetXPath(const char *lpXPath) {
      return IPWorksZip_OfficeDoc_Set(m_pObj, 37, 0, (void*)lpXPath, 0);
    }

    inline char* GetXPrefix() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 38, 0, 0);
      return (char*)val;
    }


    inline char* GetXSubTree() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 39, 0, 0);
      return (char*)val;
    }


    inline char* GetXText() {
      void* val = IPWorksZip_OfficeDoc_Get(m_pObj, 40, 0, 0);
      return (char*)val;
    }



  public: //methods

    inline int Close() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 2, 0, param, cbparam);
      
      
    }
    inline char* Config(const char* lpszConfigurationString) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszConfigurationString), 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_OfficeDoc_Do(m_pObj, 3, 1, param, cbparam);
      
      return (char*)param[1];
    }
    inline int ExtractPart() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 4, 0, param, cbparam);
      
      
    }
    inline char* FindPartByType(const char* lpszTypeURI) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszTypeURI), 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_OfficeDoc_Do(m_pObj, 5, 1, param, cbparam);
      
      return (char*)param[1];
    }
    inline char* GetPropertyValue(const char* lpszPropName, const char* lpszPropNamespace) {
      void *param[2+1] = {(void*)IPZ64CAST(lpszPropName), (void*)IPZ64CAST(lpszPropNamespace), 0};
      int cbparam[2+1] = {0, 0, 0};
      IPWorksZip_OfficeDoc_Do(m_pObj, 6, 2, param, cbparam);
      
      return (char*)param[2];
    }
    inline int ListParts() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 7, 0, param, cbparam);
      
      
    }
    inline int Open() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 8, 0, param, cbparam);
      
      
    }
    inline int ParsePart() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 9, 0, param, cbparam);
      
      
    }
    inline int ReadRelationships() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 10, 0, param, cbparam);
      
      
    }
    inline int ReplacePart() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 11, 0, param, cbparam);
      
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 12, 0, param, cbparam);
      
      
    }
    inline char* ResolveContentType() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      IPWorksZip_OfficeDoc_Do(m_pObj, 13, 0, param, cbparam);
      
      return (char*)param[0];
    }

};


#ifdef WIN32 //UNICODE

typedef struct {
  int Index;
  int Skip;
  int reserved;
} OfficeDocBeginFileEventParamsW;

typedef struct {
  LPWSTR Text;
  int lenText;
  int reserved;
} OfficeDocCharactersEventParamsW;

typedef struct {
  LPWSTR Text;
  int reserved;
} OfficeDocCommentEventParamsW;

typedef struct {
  LPWSTR Namespace;
  LPWSTR Element;
  LPWSTR QName;
  int IsEmpty;
  int reserved;
} OfficeDocEndElementEventParamsW;

typedef struct {
  int Index;
  int reserved;
} OfficeDocEndFileEventParamsW;

typedef struct {
  LPWSTR Prefix;
  int reserved;
} OfficeDocEndPrefixMappingEventParamsW;

typedef struct {
  int ErrorCode;
  LPWSTR Description;
  int reserved;
} OfficeDocErrorEventParamsW;

typedef struct {
  LPWSTR Entity;
  LPWSTR Value;
  int reserved;
} OfficeDocEvalEntityEventParamsW;

typedef struct {
  LPWSTR Text;
  int reserved;
} OfficeDocIgnorableWhitespaceEventParamsW;

typedef struct {
  LPWSTR Text;
  int reserved;
} OfficeDocMetaEventParamsW;

typedef struct {
  LPWSTR Filename;
  int Overwrite;
  int reserved;
} OfficeDocOverwriteEventParamsW;

typedef struct {
  LPWSTR Text;
  int reserved;
} OfficeDocPIEventParamsW;

typedef struct {
  LPWSTR Data;
  LPWSTR Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int lenData;
  int reserved;
} OfficeDocProgressEventParamsW;

typedef struct {
  LPWSTR SectionId;
  LPWSTR Text;
  int reserved;
} OfficeDocSpecialSectionEventParamsW;

typedef struct {
  LPWSTR Namespace;
  LPWSTR Element;
  LPWSTR QName;
  int IsEmpty;
  int reserved;
} OfficeDocStartElementEventParamsW;

typedef struct {
  LPWSTR Prefix;
  LPWSTR URI;
  int reserved;
} OfficeDocStartPrefixMappingEventParamsW;



class OfficeDocW : public OfficeDoc {

  public: //properties
  




    inline LPWSTR GetContentTypeMediaType(int iContentTypeIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+3, iContentTypeIndex, 0);
    }



    inline LPWSTR GetContentTypeTarget(int iContentTypeIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+4, iContentTypeIndex, 0);
    }





    inline LPWSTR GetNamespacePrefix(int iNamespaceIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+6, iNamespaceIndex, 0);
    }



    inline LPWSTR GetNamespaceURI(int iNamespaceIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+7, iNamespaceIndex, 0);
    }



    inline LPWSTR GetPackagePath() {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+8, 0, 0);
    }

    inline int SetPackagePath(LPWSTR lpPackagePath) {
      return IPWorksZip_OfficeDoc_Set(m_pObj, 10000+8, 0, (void*)lpPackagePath, 0);
    }



    inline LPWSTR GetPackagePropertyDataType(int iPackagePropertyIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+10, iPackagePropertyIndex, 0);
    }



    inline LPWSTR GetPackagePropertyName(int iPackagePropertyIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+11, iPackagePropertyIndex, 0);
    }



    inline LPWSTR GetPackagePropertyNamespace(int iPackagePropertyIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+12, iPackagePropertyIndex, 0);
    }



    inline LPWSTR GetPackagePropertyPropId(int iPackagePropertyIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+13, iPackagePropertyIndex, 0);
    }



    inline LPWSTR GetPackagePropertyPropSet(int iPackagePropertyIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+14, iPackagePropertyIndex, 0);
    }



    inline LPWSTR GetPackagePropertyValue(int iPackagePropertyIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+15, iPackagePropertyIndex, 0);
    }



    inline LPWSTR GetPartData() {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+16, 0, 0);
    }

    inline int SetPartData(LPWSTR lpPartData) {
      return IPWorksZip_OfficeDoc_Set(m_pObj, 10000+16, 0, (void*)lpPartData, 0);
    }
    inline int GetPartDataB(char *&lpPartData, int &lenPartData) {
      lpPartData = (char*)IPWorksZip_OfficeDoc_Get(m_pObj, 16, 0, &lenPartData);
      return lpPartData ? 0 : lenPartData;
    }
    inline int SetPartDataB(const char *lpPartData, int lenPartData) {
      return IPWorksZip_OfficeDoc_Set(m_pObj, 16, 0, (void*)lpPartData, lenPartData);
    }
    inline LPWSTR GetPartName() {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+17, 0, 0);
    }

    inline int SetPartName(LPWSTR lpPartName) {
      return IPWorksZip_OfficeDoc_Set(m_pObj, 10000+17, 0, (void*)lpPartName, 0);
    }



    inline LPWSTR GetRelationshipContentType(int iRelationshipIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+19, iRelationshipIndex, 0);
    }



    inline LPWSTR GetRelationshipId(int iRelationshipIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+20, iRelationshipIndex, 0);
    }



    inline LPWSTR GetRelationshipPartName(int iRelationshipIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+21, iRelationshipIndex, 0);
    }



    inline LPWSTR GetRelationshipTypeURI(int iRelationshipIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+22, iRelationshipIndex, 0);
    }







    inline LPWSTR GetAttrName(int iAttrIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+25, iAttrIndex, 0);
    }



    inline LPWSTR GetAttrNamespace(int iAttrIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+26, iAttrIndex, 0);
    }



    inline LPWSTR GetAttrPrefix(int iAttrIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+27, iAttrIndex, 0);
    }



    inline LPWSTR GetAttrValue(int iAttrIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+28, iAttrIndex, 0);
    }





    inline LPWSTR GetXChildName(int iXChildIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+30, iXChildIndex, 0);
    }



    inline LPWSTR GetXChildNamespace(int iXChildIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+31, iXChildIndex, 0);
    }



    inline LPWSTR GetXChildPrefix(int iXChildIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+32, iXChildIndex, 0);
    }



    inline LPWSTR GetXChildXText(int iXChildIndex) {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+33, iXChildIndex, 0);
    }



    inline LPWSTR GetXElement() {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+34, 0, 0);
    }



    inline LPWSTR GetXNamespace() {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+35, 0, 0);
    }



    inline LPWSTR GetXParent() {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+36, 0, 0);
    }



    inline LPWSTR GetXPath() {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+37, 0, 0);
    }

    inline int SetXPath(LPWSTR lpXPath) {
      return IPWorksZip_OfficeDoc_Set(m_pObj, 10000+37, 0, (void*)lpXPath, 0);
    }

    inline LPWSTR GetXPrefix() {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+38, 0, 0);
    }



    inline LPWSTR GetXSubTree() {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+39, 0, 0);
    }



    inline LPWSTR GetXText() {
      return (LPWSTR)IPWorksZip_OfficeDoc_Get(m_pObj, 10000+40, 0, 0);
    }





  public: //events
  
    virtual int FireBeginFile(OfficeDocBeginFileEventParamsW *e) {return 0;}
    virtual int FireCharacters(OfficeDocCharactersEventParamsW *e) {return 0;}
    virtual int FireComment(OfficeDocCommentEventParamsW *e) {return 0;}
    virtual int FireEndElement(OfficeDocEndElementEventParamsW *e) {return 0;}
    virtual int FireEndFile(OfficeDocEndFileEventParamsW *e) {return 0;}
    virtual int FireEndPrefixMapping(OfficeDocEndPrefixMappingEventParamsW *e) {return 0;}
    virtual int FireError(OfficeDocErrorEventParamsW *e) {return 0;}
    virtual int FireEvalEntity(OfficeDocEvalEntityEventParamsW *e) {return 0;}
    virtual int FireIgnorableWhitespace(OfficeDocIgnorableWhitespaceEventParamsW *e) {return 0;}
    virtual int FireMeta(OfficeDocMetaEventParamsW *e) {return 0;}
    virtual int FireOverwrite(OfficeDocOverwriteEventParamsW *e) {return 0;}
    virtual int FirePI(OfficeDocPIEventParamsW *e) {return 0;}
    virtual int FireProgress(OfficeDocProgressEventParamsW *e) {return 0;}
    virtual int FireSpecialSection(OfficeDocSpecialSectionEventParamsW *e) {return 0;}
    virtual int FireStartElement(OfficeDocStartElementEventParamsW *e) {return 0;}
    virtual int FireStartPrefixMapping(OfficeDocStartPrefixMappingEventParamsW *e) {return 0;}


  protected:
  
    virtual int OfficeDocEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {
    	int ret_code = 0;
      switch (event_id) {
         case 1: {
            OfficeDocBeginFileEventParamsW e = {(int)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = FireBeginFile(&e);
            param[1] = (void*)(e.Skip);
            break;
         }
         case 2: {
            OfficeDocCharactersEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = FireCharacters(&e);
            break;
         }
         case 3: {
            OfficeDocCommentEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]),  0};
            ret_code = FireComment(&e);
            break;
         }
         case 4: {
            OfficeDocEndElementEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]), (LPWSTR)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]),  0};
            ret_code = FireEndElement(&e);
            break;
         }
         case 5: {
            OfficeDocEndFileEventParamsW e = {(int)IPZ64CAST(param[0]),  0};
            ret_code = FireEndFile(&e);
            break;
         }
         case 6: {
            OfficeDocEndPrefixMappingEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]),  0};
            ret_code = FireEndPrefixMapping(&e);
            break;
         }
         case 7: {
            OfficeDocErrorEventParamsW e = {(int)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]),  0};
            ret_code = FireError(&e);
            break;
         }
         case 8: {
            OfficeDocEvalEntityEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]),  0};
            ret_code = FireEvalEntity(&e);
            param[1] = (void*)(e.Value);
            break;
         }
         case 9: {
            OfficeDocIgnorableWhitespaceEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]),  0};
            ret_code = FireIgnorableWhitespace(&e);
            break;
         }
         case 10: {
            OfficeDocMetaEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]),  0};
            ret_code = FireMeta(&e);
            break;
         }
         case 11: {
            OfficeDocOverwriteEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = FireOverwrite(&e);
            param[0] = (void*)(e.Filename);
            param[1] = (void*)(e.Overwrite);
            break;
         }
         case 12: {
            OfficeDocPIEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]),  0};
            ret_code = FirePI(&e);
            break;
         }
         case 13: {
            OfficeDocProgressEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]), (ns_int64*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = FireProgress(&e);
            break;
         }
         case 14: {
            OfficeDocSpecialSectionEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]),  0};
            ret_code = FireSpecialSection(&e);
            break;
         }
         case 15: {
            OfficeDocStartElementEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]), (LPWSTR)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]),  0};
            ret_code = FireStartElement(&e);
            break;
         }
         case 16: {
            OfficeDocStartPrefixMappingEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]),  0};
            ret_code = FireStartPrefixMapping(&e);
            break;
         }

      }
      return ret_code;
    }
  
  public: //event overrides

    virtual int FireBeginFile(OfficeDocBeginFileEventParams *e) {return -10000;}
    virtual int FireCharacters(OfficeDocCharactersEventParams *e) {return -10000;}
    virtual int FireComment(OfficeDocCommentEventParams *e) {return -10000;}
    virtual int FireEndElement(OfficeDocEndElementEventParams *e) {return -10000;}
    virtual int FireEndFile(OfficeDocEndFileEventParams *e) {return -10000;}
    virtual int FireEndPrefixMapping(OfficeDocEndPrefixMappingEventParams *e) {return -10000;}
    virtual int FireError(OfficeDocErrorEventParams *e) {return -10000;}
    virtual int FireEvalEntity(OfficeDocEvalEntityEventParams *e) {return -10000;}
    virtual int FireIgnorableWhitespace(OfficeDocIgnorableWhitespaceEventParams *e) {return -10000;}
    virtual int FireMeta(OfficeDocMetaEventParams *e) {return -10000;}
    virtual int FireOverwrite(OfficeDocOverwriteEventParams *e) {return -10000;}
    virtual int FirePI(OfficeDocPIEventParams *e) {return -10000;}
    virtual int FireProgress(OfficeDocProgressEventParams *e) {return -10000;}
    virtual int FireSpecialSection(OfficeDocSpecialSectionEventParams *e) {return -10000;}
    virtual int FireStartElement(OfficeDocStartElementEventParams *e) {return -10000;}
    virtual int FireStartPrefixMapping(OfficeDocStartPrefixMappingEventParams *e) {return -10000;}

  public: //methods

    inline int Close() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 10000+2, 0, param, cbparam);
      
    }
    inline LPWSTR Config(LPWSTR lpszConfigurationString) {
      void *param[1+1] = {(void*)lpszConfigurationString, 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_OfficeDoc_Do(m_pObj, 10000+3, 1, param, cbparam);
      return (LPWSTR)param[1];
    }
    inline int ExtractPart() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 10000+4, 0, param, cbparam);
      
    }
    inline LPWSTR FindPartByType(LPWSTR lpszTypeURI) {
      void *param[1+1] = {(void*)lpszTypeURI, 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_OfficeDoc_Do(m_pObj, 10000+5, 1, param, cbparam);
      return (LPWSTR)param[1];
    }
    inline LPWSTR GetPropertyValue(LPWSTR lpszPropName, LPWSTR lpszPropNamespace) {
      void *param[2+1] = {(void*)lpszPropName, (void*)lpszPropNamespace, 0};
      int cbparam[2+1] = {0, 0, 0};
      IPWorksZip_OfficeDoc_Do(m_pObj, 10000+6, 2, param, cbparam);
      return (LPWSTR)param[2];
    }
    inline int ListParts() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 10000+7, 0, param, cbparam);
      
    }
    inline int Open() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 10000+8, 0, param, cbparam);
      
    }
    inline int ParsePart() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 10000+9, 0, param, cbparam);
      
    }
    inline int ReadRelationships() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 10000+10, 0, param, cbparam);
      
    }
    inline int ReplacePart() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 10000+11, 0, param, cbparam);
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_OfficeDoc_Do(m_pObj, 10000+12, 0, param, cbparam);
      
    }
    inline LPWSTR ResolveContentType() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      IPWorksZip_OfficeDoc_Do(m_pObj, 10000+13, 0, param, cbparam);
      return (LPWSTR)param[0];
    }

};

#endif //WIN32

#endif //_IPWORKSZIP_OFFICEDOC_H_




