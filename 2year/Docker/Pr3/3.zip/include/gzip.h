/******************************************************************
   IP*Works! ZIP V9 C++ Edition
   Copyright (c) 2012 /n software inc. - All rights reserved.
*******************************************************************/

#ifndef _IPWORKSZIP_GZIP_H_
#define _IPWORKSZIP_GZIP_H_

#define IPWORKSZIP_ONLY_TYPES
#include "ipworkszip.h"
#include "ipworkszip.key"

//TCompressionMethod
#define CM_DEFLATE                                         0
#define CM_LZCCOMPRESS                                     1


extern "C" void* IPWORKSZIP_CALL IPWorksZip_Gzip_Create(PIPWORKSZIP_CALLBACK lpSink, void *lpContext, char *lpOemKey);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Gzip_Destroy(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Gzip_CheckIndex(void *lpObj, int propid, int arridx);
extern "C" void* IPWORKSZIP_CALL IPWorksZip_Gzip_Get(void *lpObj, int propid, int arridx, int *lpcbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Gzip_Set(void *lpObj, int propid, int arridx, const void *val, int cbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Gzip_Do(void *lpObj, int methid, int cparam, void *param[], int cbparam[]);
extern "C" char* IPWORKSZIP_CALL IPWorksZip_Gzip_GetLastError(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Gzip_GetLastErrorCode(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Gzip_StaticInit(void *hInst);

#ifdef WIN32
#include <windows.h>
#pragma warning(disable:4311) 
#pragma warning(disable:4312) 
#endif

typedef struct {
  int Index;
  int Skip;
  int reserved;
} GzipBeginFileEventParams;

typedef struct {
  int Index;
  int reserved;
} GzipEndFileEventParams;

typedef struct {
  const char* Description;
  int ErrorCode;
  int Index;
  const char* Filename;
  int Ignore;
  int reserved;
} GzipErrorEventParams;

typedef struct {
  const char* Filename;
  int Overwrite;
  int reserved;
} GzipOverwriteEventParams;

typedef struct {
  const char* Data;
  const char* Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int lenData;
  int reserved;
} GzipProgressEventParams;



class Gzip {
  
  public: //events
  
    virtual int FireBeginFile(GzipBeginFileEventParams *e) {return 0;}
    virtual int FireEndFile(GzipEndFileEventParams *e) {return 0;}
    virtual int FireError(GzipErrorEventParams *e) {return 0;}
    virtual int FireOverwrite(GzipOverwriteEventParams *e) {return 0;}
    virtual int FireProgress(GzipProgressEventParams *e) {return 0;}


  protected:

    void *m_pObj;
    
    static int IPWORKSZIP_CALL GzipEventSink(void *lpObj, int event_id, int cparam, void *param[], int cbparam[]) {
      int ret_code = 0;
      if (event_id > 10000) return ((Gzip*)lpObj)->GzipEventSinkW(event_id - 10000, cparam, param, cbparam);
      switch (event_id) {
         case 1: {
            GzipBeginFileEventParams e = {(int)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = ((Gzip*)lpObj)->FireBeginFile(&e);
            param[1] = (void*)IPZ64CAST(e.Skip);
            break;
         }
         case 2: {
            GzipEndFileEventParams e = {(int)IPZ64CAST(param[0]),  0};
            ret_code = ((Gzip*)lpObj)->FireEndFile(&e);
            break;
         }
         case 3: {
            GzipErrorEventParams e = {(char*)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]), (char*)IPZ64CAST(param[3]), (int)IPZ64CAST(param[4]),  0};
            ret_code = ((Gzip*)lpObj)->FireError(&e);
            param[4] = (void*)IPZ64CAST(e.Ignore);
            break;
         }
         case 4: {
            GzipOverwriteEventParams e = {(char*)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = ((Gzip*)lpObj)->FireOverwrite(&e);
            param[0] = (void*)IPZ64CAST(e.Filename);
            param[1] = (void*)IPZ64CAST(e.Overwrite);
            break;
         }
         case 5: {
            GzipProgressEventParams e = {(char*)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]), (ns_int64*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = ((Gzip*)lpObj)->FireProgress(&e);
            break;
         }

      }
      return ret_code;
    }

    virtual int GzipEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {return 0;}

  public:

    Gzip(char *lpOemKey = (char*)IPWORKSZIP_OEMKEY_32) {
      m_pObj = IPWorksZip_Gzip_Create(GzipEventSink, (void*)this, (char*)lpOemKey);
    }

    virtual ~Gzip() {
      IPWorksZip_Gzip_Destroy(m_pObj);
    }

  public:

    inline char *GetLastError() {
      return IPWorksZip_Gzip_GetLastError(m_pObj);
    }
    
    inline int GetLastErrorCode() {
      return IPWorksZip_Gzip_GetLastErrorCode(m_pObj);
    }

    inline char *VERSION() {
      return (char*)IPWorksZip_Gzip_Get(m_pObj, 0, 0, 0);
    }

  public: //properties

    inline char* GetArchiveFile() {
      void* val = IPWorksZip_Gzip_Get(m_pObj, 1, 0, 0);
      return (char*)val;
    }

    inline int SetArchiveFile(const char *lpArchiveFile) {
      return IPWorksZip_Gzip_Set(m_pObj, 1, 0, (void*)lpArchiveFile, 0);
    }

    inline int GetCompressionLevel() {
      void* val = IPWorksZip_Gzip_Get(m_pObj, 2, 0, 0);
      return (int)(long)val;
    }
    inline int SetCompressionLevel(int iCompressionLevel) {
      void* val = (void*)IPZ64CAST(iCompressionLevel);
      return IPWorksZip_Gzip_Set(m_pObj, 2, 0, val, 0);
    }
    inline int GetCompressionMethod() {
      void* val = IPWorksZip_Gzip_Get(m_pObj, 3, 0, 0);
      return (int)(long)val;
    }
    inline int SetCompressionMethod(int iCompressionMethod) {
      void* val = (void*)IPZ64CAST(iCompressionMethod);
      return IPWorksZip_Gzip_Set(m_pObj, 3, 0, val, 0);
    }
    inline char* GetExtractToPath() {
      void* val = IPWorksZip_Gzip_Get(m_pObj, 4, 0, 0);
      return (char*)val;
    }

    inline int SetExtractToPath(const char *lpExtractToPath) {
      return IPWorksZip_Gzip_Set(m_pObj, 4, 0, (void*)lpExtractToPath, 0);
    }

    inline ns_int64 GetFileCompressedDate() {
      ns_int64 *pval = (ns_int64*)IPWorksZip_Gzip_Get(m_pObj, 5, 0, 0);
      return *pval;
    }


    inline char* GetFileCompressedName() {
      void* val = IPWorksZip_Gzip_Get(m_pObj, 6, 0, 0);
      return (char*)val;
    }

    inline int SetFileCompressedName(const char *lpFileCompressedName) {
      return IPWorksZip_Gzip_Set(m_pObj, 6, 0, (void*)lpFileCompressedName, 0);
    }

    inline char* GetFileDecompressedName() {
      void* val = IPWorksZip_Gzip_Get(m_pObj, 7, 0, 0);
      return (char*)val;
    }

    inline int SetFileDecompressedName(const char *lpFileDecompressedName) {
      return IPWorksZip_Gzip_Set(m_pObj, 7, 0, (void*)lpFileDecompressedName, 0);
    }


    inline int SetGzipData(const char *lpGzipData, int lenGzipData) {
      return IPWorksZip_Gzip_Set(m_pObj, 8, 0, (void*)lpGzipData, lenGzipData);
    }

    inline int GetHasMoreData() {
      void* val = IPWorksZip_Gzip_Get(m_pObj, 9, 0, 0);
      return (int)(long)val;
    }


  public: //methods

    inline int Abort() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 2, 0, param, cbparam);
      
      
    }
    inline int Append() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 3, 0, param, cbparam);
      
      
    }
    inline int Compress() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 4, 0, param, cbparam);
      
      
    }
    inline char* Config(const char* lpszConfigurationString) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszConfigurationString), 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_Gzip_Do(m_pObj, 5, 1, param, cbparam);
      
      return (char*)param[1];
    }
    inline int Extract() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 6, 0, param, cbparam);
      
      
    }
    inline int ExtractAll() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 7, 0, param, cbparam);
      
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 8, 0, param, cbparam);
      
      
    }
    inline int Scan() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 9, 0, param, cbparam);
      
      
    }

};


#ifdef WIN32 //UNICODE

typedef struct {
  int Index;
  int Skip;
  int reserved;
} GzipBeginFileEventParamsW;

typedef struct {
  int Index;
  int reserved;
} GzipEndFileEventParamsW;

typedef struct {
  LPWSTR Description;
  int ErrorCode;
  int Index;
  LPWSTR Filename;
  int Ignore;
  int reserved;
} GzipErrorEventParamsW;

typedef struct {
  LPWSTR Filename;
  int Overwrite;
  int reserved;
} GzipOverwriteEventParamsW;

typedef struct {
  LPWSTR Data;
  LPWSTR Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int lenData;
  int reserved;
} GzipProgressEventParamsW;



class GzipW : public Gzip {

  public: //properties
  
    inline LPWSTR GetArchiveFile() {
      return (LPWSTR)IPWorksZip_Gzip_Get(m_pObj, 10000+1, 0, 0);
    }

    inline int SetArchiveFile(LPWSTR lpArchiveFile) {
      return IPWorksZip_Gzip_Set(m_pObj, 10000+1, 0, (void*)lpArchiveFile, 0);
    }





    inline LPWSTR GetExtractToPath() {
      return (LPWSTR)IPWorksZip_Gzip_Get(m_pObj, 10000+4, 0, 0);
    }

    inline int SetExtractToPath(LPWSTR lpExtractToPath) {
      return IPWorksZip_Gzip_Set(m_pObj, 10000+4, 0, (void*)lpExtractToPath, 0);
    }



    inline LPWSTR GetFileCompressedName() {
      return (LPWSTR)IPWorksZip_Gzip_Get(m_pObj, 10000+6, 0, 0);
    }

    inline int SetFileCompressedName(LPWSTR lpFileCompressedName) {
      return IPWorksZip_Gzip_Set(m_pObj, 10000+6, 0, (void*)lpFileCompressedName, 0);
    }

    inline LPWSTR GetFileDecompressedName() {
      return (LPWSTR)IPWorksZip_Gzip_Get(m_pObj, 10000+7, 0, 0);
    }

    inline int SetFileDecompressedName(LPWSTR lpFileDecompressedName) {
      return IPWorksZip_Gzip_Set(m_pObj, 10000+7, 0, (void*)lpFileDecompressedName, 0);
    }



    inline int SetGzipData(LPWSTR lpGzipData) {
      return IPWorksZip_Gzip_Set(m_pObj, 10000+8, 0, (void*)lpGzipData, 0);
    }

    inline int SetGzipDataB(const char *lpGzipData, int lenGzipData) {
      return IPWorksZip_Gzip_Set(m_pObj, 8, 0, (void*)lpGzipData, lenGzipData);
    }




  public: //events
  
    virtual int FireBeginFile(GzipBeginFileEventParamsW *e) {return 0;}
    virtual int FireEndFile(GzipEndFileEventParamsW *e) {return 0;}
    virtual int FireError(GzipErrorEventParamsW *e) {return 0;}
    virtual int FireOverwrite(GzipOverwriteEventParamsW *e) {return 0;}
    virtual int FireProgress(GzipProgressEventParamsW *e) {return 0;}


  protected:
  
    virtual int GzipEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {
    	int ret_code = 0;
      switch (event_id) {
         case 1: {
            GzipBeginFileEventParamsW e = {(int)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = FireBeginFile(&e);
            param[1] = (void*)(e.Skip);
            break;
         }
         case 2: {
            GzipEndFileEventParamsW e = {(int)IPZ64CAST(param[0]),  0};
            ret_code = FireEndFile(&e);
            break;
         }
         case 3: {
            GzipErrorEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]), (LPWSTR)IPZ64CAST(param[3]), (int)IPZ64CAST(param[4]),  0};
            ret_code = FireError(&e);
            param[4] = (void*)(e.Ignore);
            break;
         }
         case 4: {
            GzipOverwriteEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = FireOverwrite(&e);
            param[0] = (void*)(e.Filename);
            param[1] = (void*)(e.Overwrite);
            break;
         }
         case 5: {
            GzipProgressEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]), (ns_int64*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = FireProgress(&e);
            break;
         }

      }
      return ret_code;
    }
  
  public: //event overrides

    virtual int FireBeginFile(GzipBeginFileEventParams *e) {return -10000;}
    virtual int FireEndFile(GzipEndFileEventParams *e) {return -10000;}
    virtual int FireError(GzipErrorEventParams *e) {return -10000;}
    virtual int FireOverwrite(GzipOverwriteEventParams *e) {return -10000;}
    virtual int FireProgress(GzipProgressEventParams *e) {return -10000;}

  public: //methods

    inline int Abort() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 10000+2, 0, param, cbparam);
      
    }
    inline int Append() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 10000+3, 0, param, cbparam);
      
    }
    inline int Compress() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 10000+4, 0, param, cbparam);
      
    }
    inline LPWSTR Config(LPWSTR lpszConfigurationString) {
      void *param[1+1] = {(void*)lpszConfigurationString, 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_Gzip_Do(m_pObj, 10000+5, 1, param, cbparam);
      return (LPWSTR)param[1];
    }
    inline int Extract() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 10000+6, 0, param, cbparam);
      
    }
    inline int ExtractAll() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 10000+7, 0, param, cbparam);
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 10000+8, 0, param, cbparam);
      
    }
    inline int Scan() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Gzip_Do(m_pObj, 10000+9, 0, param, cbparam);
      
    }

};

#endif //WIN32

#endif //_IPWORKSZIP_GZIP_H_




