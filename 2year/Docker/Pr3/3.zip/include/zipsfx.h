/******************************************************************
   IP*Works! ZIP V9 C++ Edition
   Copyright (c) 2012 /n software inc. - All rights reserved.
*******************************************************************/

#ifndef _IPWORKSZIP_ZIPSFX_H_
#define _IPWORKSZIP_ZIPSFX_H_

#define IPWORKSZIP_ONLY_TYPES
#include "ipworkszip.h"
#include "ipworkszip.key"


extern "C" void* IPWORKSZIP_CALL IPWorksZip_ZipSFX_Create(PIPWORKSZIP_CALLBACK lpSink, void *lpContext, char *lpOemKey);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_ZipSFX_Destroy(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_ZipSFX_CheckIndex(void *lpObj, int propid, int arridx);
extern "C" void* IPWORKSZIP_CALL IPWorksZip_ZipSFX_Get(void *lpObj, int propid, int arridx, int *lpcbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_ZipSFX_Set(void *lpObj, int propid, int arridx, const void *val, int cbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_ZipSFX_Do(void *lpObj, int methid, int cparam, void *param[], int cbparam[]);
extern "C" char* IPWORKSZIP_CALL IPWorksZip_ZipSFX_GetLastError(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_ZipSFX_GetLastErrorCode(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_ZipSFX_StaticInit(void *hInst);

#ifdef WIN32
#include <windows.h>
#pragma warning(disable:4311) 
#pragma warning(disable:4312) 
#endif

typedef struct {
  const char* Description;
  int ErrorCode;
  int Index;
  const char* Filename;
  int Ignore;
  int reserved;
} ZipSFXErrorEventParams;

typedef struct {
  const char* Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int reserved;
} ZipSFXProgressEventParams;



class ZipSFX {
  
  public: //events
  
    virtual int FireError(ZipSFXErrorEventParams *e) {return 0;}
    virtual int FireProgress(ZipSFXProgressEventParams *e) {return 0;}


  protected:

    void *m_pObj;
    
    static int IPWORKSZIP_CALL ZipSFXEventSink(void *lpObj, int event_id, int cparam, void *param[], int cbparam[]) {
      int ret_code = 0;
      if (event_id > 10000) return ((ZipSFX*)lpObj)->ZipSFXEventSinkW(event_id - 10000, cparam, param, cbparam);
      switch (event_id) {
         case 1: {
            ZipSFXErrorEventParams e = {(char*)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]), (char*)IPZ64CAST(param[3]), (int)IPZ64CAST(param[4]),  0};
            ret_code = ((ZipSFX*)lpObj)->FireError(&e);
            param[4] = (void*)IPZ64CAST(e.Ignore);
            break;
         }
         case 2: {
            ZipSFXProgressEventParams e = {(char*)IPZ64CAST(param[0]), (ns_int64*)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]),  0};
            ret_code = ((ZipSFX*)lpObj)->FireProgress(&e);
            break;
         }

      }
      return ret_code;
    }

    virtual int ZipSFXEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {return 0;}

  public:

    ZipSFX(char *lpOemKey = (char*)IPWORKSZIP_OEMKEY_39) {
      m_pObj = IPWorksZip_ZipSFX_Create(ZipSFXEventSink, (void*)this, (char*)lpOemKey);
    }

    virtual ~ZipSFX() {
      IPWorksZip_ZipSFX_Destroy(m_pObj);
    }

  public:

    inline char *GetLastError() {
      return IPWorksZip_ZipSFX_GetLastError(m_pObj);
    }
    
    inline int GetLastErrorCode() {
      return IPWorksZip_ZipSFX_GetLastErrorCode(m_pObj);
    }

    inline char *VERSION() {
      return (char*)IPWorksZip_ZipSFX_Get(m_pObj, 0, 0, 0);
    }

  public: //properties

    inline char* GetArchiveFile() {
      void* val = IPWorksZip_ZipSFX_Get(m_pObj, 1, 0, 0);
      return (char*)val;
    }

    inline int SetArchiveFile(const char *lpArchiveFile) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 1, 0, (void*)lpArchiveFile, 0);
    }

    inline char* GetBannerText() {
      void* val = IPWorksZip_ZipSFX_Get(m_pObj, 2, 0, 0);
      return (char*)val;
    }

    inline int SetBannerText(const char *lpBannerText) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 2, 0, (void*)lpBannerText, 0);
    }

    inline char* GetCaptionText() {
      void* val = IPWorksZip_ZipSFX_Get(m_pObj, 3, 0, 0);
      return (char*)val;
    }

    inline int SetCaptionText(const char *lpCaptionText) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 3, 0, (void*)lpCaptionText, 0);
    }

    inline int GetCompressionLevel() {
      void* val = IPWorksZip_ZipSFX_Get(m_pObj, 4, 0, 0);
      return (int)(long)val;
    }
    inline int SetCompressionLevel(int iCompressionLevel) {
      void* val = (void*)IPZ64CAST(iCompressionLevel);
      return IPWorksZip_ZipSFX_Set(m_pObj, 4, 0, val, 0);
    }
    inline char* GetExtractToPath() {
      void* val = IPWorksZip_ZipSFX_Get(m_pObj, 5, 0, 0);
      return (char*)val;
    }

    inline int SetExtractToPath(const char *lpExtractToPath) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 5, 0, (void*)lpExtractToPath, 0);
    }

    inline char* GetFileToExecute() {
      void* val = IPWorksZip_ZipSFX_Get(m_pObj, 6, 0, 0);
      return (char*)val;
    }

    inline int SetFileToExecute(const char *lpFileToExecute) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 6, 0, (void*)lpFileToExecute, 0);
    }

    inline char* GetPassword() {
      void* val = IPWorksZip_ZipSFX_Get(m_pObj, 7, 0, 0);
      return (char*)val;
    }

    inline int SetPassword(const char *lpPassword) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 7, 0, (void*)lpPassword, 0);
    }

    inline int GetRecurseSubdirectories() {
      void* val = IPWorksZip_ZipSFX_Get(m_pObj, 8, 0, 0);
      return (int)(long)val;
    }
    inline int SetRecurseSubdirectories(int bRecurseSubdirectories) {
      void* val = (void*)IPZ64CAST(bRecurseSubdirectories);
      return IPWorksZip_ZipSFX_Set(m_pObj, 8, 0, val, 0);
    }
    inline char* GetSourceDirectory() {
      void* val = IPWorksZip_ZipSFX_Get(m_pObj, 9, 0, 0);
      return (char*)val;
    }

    inline int SetSourceDirectory(const char *lpSourceDirectory) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 9, 0, (void*)lpSourceDirectory, 0);
    }


  public: //methods

    inline char* Config(const char* lpszConfigurationString) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszConfigurationString), 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_ZipSFX_Do(m_pObj, 2, 1, param, cbparam);
      
      return (char*)param[1];
    }
    inline int CreateSFX() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_ZipSFX_Do(m_pObj, 3, 0, param, cbparam);
      
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_ZipSFX_Do(m_pObj, 4, 0, param, cbparam);
      
      
    }

};


#ifdef WIN32 //UNICODE

typedef struct {
  LPWSTR Description;
  int ErrorCode;
  int Index;
  LPWSTR Filename;
  int Ignore;
  int reserved;
} ZipSFXErrorEventParamsW;

typedef struct {
  LPWSTR Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int reserved;
} ZipSFXProgressEventParamsW;



class ZipSFXW : public ZipSFX {

  public: //properties
  
    inline LPWSTR GetArchiveFile() {
      return (LPWSTR)IPWorksZip_ZipSFX_Get(m_pObj, 10000+1, 0, 0);
    }

    inline int SetArchiveFile(LPWSTR lpArchiveFile) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 10000+1, 0, (void*)lpArchiveFile, 0);
    }

    inline LPWSTR GetBannerText() {
      return (LPWSTR)IPWorksZip_ZipSFX_Get(m_pObj, 10000+2, 0, 0);
    }

    inline int SetBannerText(LPWSTR lpBannerText) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 10000+2, 0, (void*)lpBannerText, 0);
    }

    inline LPWSTR GetCaptionText() {
      return (LPWSTR)IPWorksZip_ZipSFX_Get(m_pObj, 10000+3, 0, 0);
    }

    inline int SetCaptionText(LPWSTR lpCaptionText) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 10000+3, 0, (void*)lpCaptionText, 0);
    }



    inline LPWSTR GetExtractToPath() {
      return (LPWSTR)IPWorksZip_ZipSFX_Get(m_pObj, 10000+5, 0, 0);
    }

    inline int SetExtractToPath(LPWSTR lpExtractToPath) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 10000+5, 0, (void*)lpExtractToPath, 0);
    }

    inline LPWSTR GetFileToExecute() {
      return (LPWSTR)IPWorksZip_ZipSFX_Get(m_pObj, 10000+6, 0, 0);
    }

    inline int SetFileToExecute(LPWSTR lpFileToExecute) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 10000+6, 0, (void*)lpFileToExecute, 0);
    }

    inline LPWSTR GetPassword() {
      return (LPWSTR)IPWorksZip_ZipSFX_Get(m_pObj, 10000+7, 0, 0);
    }

    inline int SetPassword(LPWSTR lpPassword) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 10000+7, 0, (void*)lpPassword, 0);
    }



    inline LPWSTR GetSourceDirectory() {
      return (LPWSTR)IPWorksZip_ZipSFX_Get(m_pObj, 10000+9, 0, 0);
    }

    inline int SetSourceDirectory(LPWSTR lpSourceDirectory) {
      return IPWorksZip_ZipSFX_Set(m_pObj, 10000+9, 0, (void*)lpSourceDirectory, 0);
    }



  public: //events
  
    virtual int FireError(ZipSFXErrorEventParamsW *e) {return 0;}
    virtual int FireProgress(ZipSFXProgressEventParamsW *e) {return 0;}


  protected:
  
    virtual int ZipSFXEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {
    	int ret_code = 0;
      switch (event_id) {
         case 1: {
            ZipSFXErrorEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]), (LPWSTR)IPZ64CAST(param[3]), (int)IPZ64CAST(param[4]),  0};
            ret_code = FireError(&e);
            param[4] = (void*)(e.Ignore);
            break;
         }
         case 2: {
            ZipSFXProgressEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (ns_int64*)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]),  0};
            ret_code = FireProgress(&e);
            break;
         }

      }
      return ret_code;
    }
  
  public: //event overrides

    virtual int FireError(ZipSFXErrorEventParams *e) {return -10000;}
    virtual int FireProgress(ZipSFXProgressEventParams *e) {return -10000;}

  public: //methods

    inline LPWSTR Config(LPWSTR lpszConfigurationString) {
      void *param[1+1] = {(void*)lpszConfigurationString, 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_ZipSFX_Do(m_pObj, 10000+2, 1, param, cbparam);
      return (LPWSTR)param[1];
    }
    inline int CreateSFX() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_ZipSFX_Do(m_pObj, 10000+3, 0, param, cbparam);
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_ZipSFX_Do(m_pObj, 10000+4, 0, param, cbparam);
      
    }

};

#endif //WIN32

#endif //_IPWORKSZIP_ZIPSFX_H_




