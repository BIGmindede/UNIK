// IP*Works! ZIP V9 C++ Edition - C++ Interface
//
// Copyright (c) 2012 /n software inc. - All rights reserved.
//

#ifndef _IPWORKSZIP_H_
#define _IPWORKSZIP_H_
  
#ifdef WIN32
#define IPWORKSZIP_CALL __stdcall
#else //UNIX
#define IPWORKSZIP_CALL
#endif

#if defined(_MSC_VER) || defined(__BORLANDC__)
  typedef __int64 ns_int64;
  typedef unsigned __int64 ns_uint64;
#else
  typedef long long int ns_int64;
  typedef unsigned long long int ns_uint64;
#endif


#ifdef UNIX
#if defined(__LP64__) || defined(__x86_64__) || defined(__ia64__) || defined(__amd64__) || defined(__ppc64__)
#ifndef UNIX64
#define UNIX64
#endif
#endif
#endif

#ifndef UNIX64
#define IPZ64CAST
#else
#define IPZ64CAST (ns_int64)
#endif

typedef int (IPWORKSZIP_CALL *PIPWORKSZIP_CALLBACK)
  (void *lpObj, int event_id, int cparam, void *param[], int cbparam[]);

#ifndef IPWORKSZIP_ONLY_TYPES
#ifdef WIN32

#include "bzip2.h"
#include "gzip.h"
#include "jar.h"
#include "officedoc.h"
#include "tar.h"
#include "zcompress.h"
#include "zip.h"
#include "zipsfx.h"


#else //UNIX

#include "bzip2.h"
#include "gzip.h"
#include "jar.h"
#include "officedoc.h"
#include "tar.h"
#include "zcompress.h"
#include "zip.h"


#endif
#endif //IPWORKSZIP_ONLY_TYPES

#endif //_IPWORKSZIP_H_


