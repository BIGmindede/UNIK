/******************************************************************
   IP*Works! ZIP V9 C++ Edition
   Copyright (c) 2012 /n software inc. - All rights reserved.
*******************************************************************/

#ifndef _IPWORKSZIP_JAR_H_
#define _IPWORKSZIP_JAR_H_

#define IPWORKSZIP_ONLY_TYPES
#include "ipworkszip.h"
#include "ipworkszip.key"


extern "C" void* IPWORKSZIP_CALL IPWorksZip_Jar_Create(PIPWORKSZIP_CALLBACK lpSink, void *lpContext, char *lpOemKey);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Jar_Destroy(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Jar_CheckIndex(void *lpObj, int propid, int arridx);
extern "C" void* IPWORKSZIP_CALL IPWorksZip_Jar_Get(void *lpObj, int propid, int arridx, int *lpcbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Jar_Set(void *lpObj, int propid, int arridx, const void *val, int cbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Jar_Do(void *lpObj, int methid, int cparam, void *param[], int cbparam[]);
extern "C" char* IPWORKSZIP_CALL IPWorksZip_Jar_GetLastError(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Jar_GetLastErrorCode(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Jar_StaticInit(void *hInst);

#ifdef WIN32
#include <windows.h>
#pragma warning(disable:4311) 
#pragma warning(disable:4312) 
#endif

typedef struct {
  int Index;
  int Skip;
  int reserved;
} JarBeginFileEventParams;

typedef struct {
  int Index;
  int reserved;
} JarEndFileEventParams;

typedef struct {
  const char* Description;
  int ErrorCode;
  int Index;
  const char* Filename;
  int Ignore;
  int reserved;
} JarErrorEventParams;

typedef struct {
  const char* Filename;
  int Overwrite;
  int reserved;
} JarOverwriteEventParams;

typedef struct {
  const char* Data;
  const char* Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int lenData;
  int reserved;
} JarProgressEventParams;



class Jar {
  
  public: //events
  
    virtual int FireBeginFile(JarBeginFileEventParams *e) {return 0;}
    virtual int FireEndFile(JarEndFileEventParams *e) {return 0;}
    virtual int FireError(JarErrorEventParams *e) {return 0;}
    virtual int FireOverwrite(JarOverwriteEventParams *e) {return 0;}
    virtual int FireProgress(JarProgressEventParams *e) {return 0;}


  protected:

    void *m_pObj;
    
    static int IPWORKSZIP_CALL JarEventSink(void *lpObj, int event_id, int cparam, void *param[], int cbparam[]) {
      int ret_code = 0;
      if (event_id > 10000) return ((Jar*)lpObj)->JarEventSinkW(event_id - 10000, cparam, param, cbparam);
      switch (event_id) {
         case 1: {
            JarBeginFileEventParams e = {(int)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = ((Jar*)lpObj)->FireBeginFile(&e);
            param[1] = (void*)IPZ64CAST(e.Skip);
            break;
         }
         case 2: {
            JarEndFileEventParams e = {(int)IPZ64CAST(param[0]),  0};
            ret_code = ((Jar*)lpObj)->FireEndFile(&e);
            break;
         }
         case 3: {
            JarErrorEventParams e = {(char*)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]), (char*)IPZ64CAST(param[3]), (int)IPZ64CAST(param[4]),  0};
            ret_code = ((Jar*)lpObj)->FireError(&e);
            param[4] = (void*)IPZ64CAST(e.Ignore);
            break;
         }
         case 4: {
            JarOverwriteEventParams e = {(char*)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = ((Jar*)lpObj)->FireOverwrite(&e);
            param[0] = (void*)IPZ64CAST(e.Filename);
            param[1] = (void*)IPZ64CAST(e.Overwrite);
            break;
         }
         case 5: {
            JarProgressEventParams e = {(char*)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]), (ns_int64*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = ((Jar*)lpObj)->FireProgress(&e);
            break;
         }

      }
      return ret_code;
    }

    virtual int JarEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {return 0;}

  public:

    Jar(char *lpOemKey = (char*)IPWORKSZIP_OEMKEY_33) {
      m_pObj = IPWorksZip_Jar_Create(JarEventSink, (void*)this, (char*)lpOemKey);
    }

    virtual ~Jar() {
      IPWorksZip_Jar_Destroy(m_pObj);
    }

  public:

    inline char *GetLastError() {
      return IPWorksZip_Jar_GetLastError(m_pObj);
    }
    
    inline int GetLastErrorCode() {
      return IPWorksZip_Jar_GetLastErrorCode(m_pObj);
    }

    inline char *VERSION() {
      return (char*)IPWorksZip_Jar_Get(m_pObj, 0, 0, 0);
    }

  public: //properties

    inline char* GetArchiveFile() {
      void* val = IPWorksZip_Jar_Get(m_pObj, 1, 0, 0);
      return (char*)val;
    }

    inline int SetArchiveFile(const char *lpArchiveFile) {
      return IPWorksZip_Jar_Set(m_pObj, 1, 0, (void*)lpArchiveFile, 0);
    }

    inline int GetCompressionLevel() {
      void* val = IPWorksZip_Jar_Get(m_pObj, 2, 0, 0);
      return (int)(long)val;
    }
    inline int SetCompressionLevel(int iCompressionLevel) {
      void* val = (void*)IPZ64CAST(iCompressionLevel);
      return IPWorksZip_Jar_Set(m_pObj, 2, 0, val, 0);
    }
    inline char* GetExcludedFiles() {
      void* val = IPWorksZip_Jar_Get(m_pObj, 3, 0, 0);
      return (char*)val;
    }

    inline int SetExcludedFiles(const char *lpExcludedFiles) {
      return IPWorksZip_Jar_Set(m_pObj, 3, 0, (void*)lpExcludedFiles, 0);
    }

    inline char* GetExtractToPath() {
      void* val = IPWorksZip_Jar_Get(m_pObj, 4, 0, 0);
      return (char*)val;
    }

    inline int SetExtractToPath(const char *lpExtractToPath) {
      return IPWorksZip_Jar_Set(m_pObj, 4, 0, (void*)lpExtractToPath, 0);
    }

    inline int GetFileCount() {
      void* val = IPWorksZip_Jar_Get(m_pObj, 5, 0, 0);
      return (int)(long)val;
    }
    inline int SetFileCount(int iFileCount) {
      void* val = (void*)IPZ64CAST(iFileCount);
      return IPWorksZip_Jar_Set(m_pObj, 5, 0, val, 0);
    }
    inline ns_int64 GetFileCompressedDate(int iFileIndex) {
      ns_int64 *pval = (ns_int64*)IPWorksZip_Jar_Get(m_pObj, 6, iFileIndex, 0);
      return *pval;
    }

    inline int SetFileCompressedDate(int iFileIndex, ns_int64 lFileCompressedDate) {
      void* val = (void*)(&lFileCompressedDate);
      return IPWorksZip_Jar_Set(m_pObj, 6, iFileIndex, val, 0);
    }

    inline char* GetFileCompressedName(int iFileIndex) {
      void* val = IPWorksZip_Jar_Get(m_pObj, 7, iFileIndex, 0);
      return (char*)val;
    }

    inline int SetFileCompressedName(int iFileIndex, const char *lpFileCompressedName) {
      return IPWorksZip_Jar_Set(m_pObj, 7, iFileIndex, (void*)lpFileCompressedName, 0);
    }

    inline ns_int64 GetFileCompressedSize(int iFileIndex) {
      ns_int64 *pval = (ns_int64*)IPWorksZip_Jar_Get(m_pObj, 8, iFileIndex, 0);
      return *pval;
    }


    inline char* GetFileDecompressedName(int iFileIndex) {
      void* val = IPWorksZip_Jar_Get(m_pObj, 9, iFileIndex, 0);
      return (char*)val;
    }

    inline int SetFileDecompressedName(int iFileIndex, const char *lpFileDecompressedName) {
      return IPWorksZip_Jar_Set(m_pObj, 9, iFileIndex, (void*)lpFileDecompressedName, 0);
    }

    inline ns_int64 GetFileDecompressedSize(int iFileIndex) {
      ns_int64 *pval = (ns_int64*)IPWorksZip_Jar_Get(m_pObj, 10, iFileIndex, 0);
      return *pval;
    }


    inline char* GetManifestFile() {
      void* val = IPWorksZip_Jar_Get(m_pObj, 11, 0, 0);
      return (char*)val;
    }

    inline int SetManifestFile(const char *lpManifestFile) {
      return IPWorksZip_Jar_Set(m_pObj, 11, 0, (void*)lpManifestFile, 0);
    }

    inline int GetOverwriteFiles() {
      void* val = IPWorksZip_Jar_Get(m_pObj, 12, 0, 0);
      return (int)(long)val;
    }
    inline int SetOverwriteFiles(int bOverwriteFiles) {
      void* val = (void*)IPZ64CAST(bOverwriteFiles);
      return IPWorksZip_Jar_Set(m_pObj, 12, 0, val, 0);
    }
    inline int GetRecurseSubdirectories() {
      void* val = IPWorksZip_Jar_Get(m_pObj, 13, 0, 0);
      return (int)(long)val;
    }
    inline int SetRecurseSubdirectories(int bRecurseSubdirectories) {
      void* val = (void*)IPZ64CAST(bRecurseSubdirectories);
      return IPWorksZip_Jar_Set(m_pObj, 13, 0, val, 0);
    }

  public: //methods

    inline int Abort() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 2, 0, param, cbparam);
      
      
    }
    inline int AppendFiles() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 3, 0, param, cbparam);
      
      
    }
    inline int Compress() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 4, 0, param, cbparam);
      
      
    }
    inline char* Config(const char* lpszConfigurationString) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszConfigurationString), 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_Jar_Do(m_pObj, 5, 1, param, cbparam);
      
      return (char*)param[1];
    }
    inline int Delete(const char* lpszFilenames) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszFilenames), 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Jar_Do(m_pObj, 6, 1, param, cbparam);
      
      
    }
    inline int Extract(const char* lpszFilenames) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszFilenames), 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Jar_Do(m_pObj, 7, 1, param, cbparam);
      
      
    }
    inline int ExtractAll() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 8, 0, param, cbparam);
      
      
    }
    inline int IncludeFiles(const char* lpszfilenames) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszfilenames), 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Jar_Do(m_pObj, 9, 1, param, cbparam);
      
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 10, 0, param, cbparam);
      
      
    }
    inline int Scan() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 11, 0, param, cbparam);
      
      
    }

};


#ifdef WIN32 //UNICODE

typedef struct {
  int Index;
  int Skip;
  int reserved;
} JarBeginFileEventParamsW;

typedef struct {
  int Index;
  int reserved;
} JarEndFileEventParamsW;

typedef struct {
  LPWSTR Description;
  int ErrorCode;
  int Index;
  LPWSTR Filename;
  int Ignore;
  int reserved;
} JarErrorEventParamsW;

typedef struct {
  LPWSTR Filename;
  int Overwrite;
  int reserved;
} JarOverwriteEventParamsW;

typedef struct {
  LPWSTR Data;
  LPWSTR Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int lenData;
  int reserved;
} JarProgressEventParamsW;



class JarW : public Jar {

  public: //properties
  
    inline LPWSTR GetArchiveFile() {
      return (LPWSTR)IPWorksZip_Jar_Get(m_pObj, 10000+1, 0, 0);
    }

    inline int SetArchiveFile(LPWSTR lpArchiveFile) {
      return IPWorksZip_Jar_Set(m_pObj, 10000+1, 0, (void*)lpArchiveFile, 0);
    }



    inline LPWSTR GetExcludedFiles() {
      return (LPWSTR)IPWorksZip_Jar_Get(m_pObj, 10000+3, 0, 0);
    }

    inline int SetExcludedFiles(LPWSTR lpExcludedFiles) {
      return IPWorksZip_Jar_Set(m_pObj, 10000+3, 0, (void*)lpExcludedFiles, 0);
    }

    inline LPWSTR GetExtractToPath() {
      return (LPWSTR)IPWorksZip_Jar_Get(m_pObj, 10000+4, 0, 0);
    }

    inline int SetExtractToPath(LPWSTR lpExtractToPath) {
      return IPWorksZip_Jar_Set(m_pObj, 10000+4, 0, (void*)lpExtractToPath, 0);
    }





    inline LPWSTR GetFileCompressedName(int iFileIndex) {
      return (LPWSTR)IPWorksZip_Jar_Get(m_pObj, 10000+7, iFileIndex, 0);
    }

    inline int SetFileCompressedName(int iFileIndex, LPWSTR lpFileCompressedName) {
      return IPWorksZip_Jar_Set(m_pObj, 10000+7, iFileIndex, (void*)lpFileCompressedName, 0);
    }



    inline LPWSTR GetFileDecompressedName(int iFileIndex) {
      return (LPWSTR)IPWorksZip_Jar_Get(m_pObj, 10000+9, iFileIndex, 0);
    }

    inline int SetFileDecompressedName(int iFileIndex, LPWSTR lpFileDecompressedName) {
      return IPWorksZip_Jar_Set(m_pObj, 10000+9, iFileIndex, (void*)lpFileDecompressedName, 0);
    }



    inline LPWSTR GetManifestFile() {
      return (LPWSTR)IPWorksZip_Jar_Get(m_pObj, 10000+11, 0, 0);
    }

    inline int SetManifestFile(LPWSTR lpManifestFile) {
      return IPWorksZip_Jar_Set(m_pObj, 10000+11, 0, (void*)lpManifestFile, 0);
    }







  public: //events
  
    virtual int FireBeginFile(JarBeginFileEventParamsW *e) {return 0;}
    virtual int FireEndFile(JarEndFileEventParamsW *e) {return 0;}
    virtual int FireError(JarErrorEventParamsW *e) {return 0;}
    virtual int FireOverwrite(JarOverwriteEventParamsW *e) {return 0;}
    virtual int FireProgress(JarProgressEventParamsW *e) {return 0;}


  protected:
  
    virtual int JarEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {
    	int ret_code = 0;
      switch (event_id) {
         case 1: {
            JarBeginFileEventParamsW e = {(int)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = FireBeginFile(&e);
            param[1] = (void*)(e.Skip);
            break;
         }
         case 2: {
            JarEndFileEventParamsW e = {(int)IPZ64CAST(param[0]),  0};
            ret_code = FireEndFile(&e);
            break;
         }
         case 3: {
            JarErrorEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]), (LPWSTR)IPZ64CAST(param[3]), (int)IPZ64CAST(param[4]),  0};
            ret_code = FireError(&e);
            param[4] = (void*)(e.Ignore);
            break;
         }
         case 4: {
            JarOverwriteEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = FireOverwrite(&e);
            param[0] = (void*)(e.Filename);
            param[1] = (void*)(e.Overwrite);
            break;
         }
         case 5: {
            JarProgressEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]), (ns_int64*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = FireProgress(&e);
            break;
         }

      }
      return ret_code;
    }
  
  public: //event overrides

    virtual int FireBeginFile(JarBeginFileEventParams *e) {return -10000;}
    virtual int FireEndFile(JarEndFileEventParams *e) {return -10000;}
    virtual int FireError(JarErrorEventParams *e) {return -10000;}
    virtual int FireOverwrite(JarOverwriteEventParams *e) {return -10000;}
    virtual int FireProgress(JarProgressEventParams *e) {return -10000;}

  public: //methods

    inline int Abort() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 10000+2, 0, param, cbparam);
      
    }
    inline int AppendFiles() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 10000+3, 0, param, cbparam);
      
    }
    inline int Compress() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 10000+4, 0, param, cbparam);
      
    }
    inline LPWSTR Config(LPWSTR lpszConfigurationString) {
      void *param[1+1] = {(void*)lpszConfigurationString, 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_Jar_Do(m_pObj, 10000+5, 1, param, cbparam);
      return (LPWSTR)param[1];
    }
    inline int Delete(LPWSTR lpszFilenames) {
      void *param[1+1] = {(void*)lpszFilenames, 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Jar_Do(m_pObj, 10000+6, 1, param, cbparam);
      
    }
    inline int Extract(LPWSTR lpszFilenames) {
      void *param[1+1] = {(void*)lpszFilenames, 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Jar_Do(m_pObj, 10000+7, 1, param, cbparam);
      
    }
    inline int ExtractAll() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 10000+8, 0, param, cbparam);
      
    }
    inline int IncludeFiles(LPWSTR lpszfilenames) {
      void *param[1+1] = {(void*)lpszfilenames, 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Jar_Do(m_pObj, 10000+9, 1, param, cbparam);
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 10000+10, 0, param, cbparam);
      
    }
    inline int Scan() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Jar_Do(m_pObj, 10000+11, 0, param, cbparam);
      
    }

};

#endif //WIN32

#endif //_IPWORKSZIP_JAR_H_




