/******************************************************************
   IP*Works! ZIP V9 C++ Edition
   Copyright (c) 2012 /n software inc. - All rights reserved.
*******************************************************************/

#ifndef _IPWORKSZIP_TAR_H_
#define _IPWORKSZIP_TAR_H_

#define IPWORKSZIP_ONLY_TYPES
#include "ipworkszip.h"
#include "ipworkszip.key"


extern "C" void* IPWORKSZIP_CALL IPWorksZip_Tar_Create(PIPWORKSZIP_CALLBACK lpSink, void *lpContext, char *lpOemKey);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Tar_Destroy(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Tar_CheckIndex(void *lpObj, int propid, int arridx);
extern "C" void* IPWORKSZIP_CALL IPWorksZip_Tar_Get(void *lpObj, int propid, int arridx, int *lpcbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Tar_Set(void *lpObj, int propid, int arridx, const void *val, int cbVal);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Tar_Do(void *lpObj, int methid, int cparam, void *param[], int cbparam[]);
extern "C" char* IPWORKSZIP_CALL IPWorksZip_Tar_GetLastError(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Tar_GetLastErrorCode(void *lpObj);
extern "C" int   IPWORKSZIP_CALL IPWorksZip_Tar_StaticInit(void *hInst);

#ifdef WIN32
#include <windows.h>
#pragma warning(disable:4311) 
#pragma warning(disable:4312) 
#endif

typedef struct {
  int Index;
  int Skip;
  int reserved;
} TarBeginFileEventParams;

typedef struct {
  int Index;
  int reserved;
} TarEndFileEventParams;

typedef struct {
  const char* Description;
  int ErrorCode;
  int Index;
  const char* Filename;
  int Ignore;
  int reserved;
} TarErrorEventParams;

typedef struct {
  const char* Filename;
  int Overwrite;
  int reserved;
} TarOverwriteEventParams;

typedef struct {
  const char* Data;
  const char* Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int lenData;
  int reserved;
} TarProgressEventParams;



class Tar {
  
  public: //events
  
    virtual int FireBeginFile(TarBeginFileEventParams *e) {return 0;}
    virtual int FireEndFile(TarEndFileEventParams *e) {return 0;}
    virtual int FireError(TarErrorEventParams *e) {return 0;}
    virtual int FireOverwrite(TarOverwriteEventParams *e) {return 0;}
    virtual int FireProgress(TarProgressEventParams *e) {return 0;}


  protected:

    void *m_pObj;
    
    static int IPWORKSZIP_CALL TarEventSink(void *lpObj, int event_id, int cparam, void *param[], int cbparam[]) {
      int ret_code = 0;
      if (event_id > 10000) return ((Tar*)lpObj)->TarEventSinkW(event_id - 10000, cparam, param, cbparam);
      switch (event_id) {
         case 1: {
            TarBeginFileEventParams e = {(int)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = ((Tar*)lpObj)->FireBeginFile(&e);
            param[1] = (void*)IPZ64CAST(e.Skip);
            break;
         }
         case 2: {
            TarEndFileEventParams e = {(int)IPZ64CAST(param[0]),  0};
            ret_code = ((Tar*)lpObj)->FireEndFile(&e);
            break;
         }
         case 3: {
            TarErrorEventParams e = {(char*)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]), (char*)IPZ64CAST(param[3]), (int)IPZ64CAST(param[4]),  0};
            ret_code = ((Tar*)lpObj)->FireError(&e);
            param[4] = (void*)IPZ64CAST(e.Ignore);
            break;
         }
         case 4: {
            TarOverwriteEventParams e = {(char*)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = ((Tar*)lpObj)->FireOverwrite(&e);
            param[0] = (void*)IPZ64CAST(e.Filename);
            param[1] = (void*)IPZ64CAST(e.Overwrite);
            break;
         }
         case 5: {
            TarProgressEventParams e = {(char*)IPZ64CAST(param[0]), (char*)IPZ64CAST(param[1]), (ns_int64*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = ((Tar*)lpObj)->FireProgress(&e);
            break;
         }

      }
      return ret_code;
    }

    virtual int TarEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {return 0;}

  public:

    Tar(char *lpOemKey = (char*)IPWORKSZIP_OEMKEY_34) {
      m_pObj = IPWorksZip_Tar_Create(TarEventSink, (void*)this, (char*)lpOemKey);
    }

    virtual ~Tar() {
      IPWorksZip_Tar_Destroy(m_pObj);
    }

  public:

    inline char *GetLastError() {
      return IPWorksZip_Tar_GetLastError(m_pObj);
    }
    
    inline int GetLastErrorCode() {
      return IPWorksZip_Tar_GetLastErrorCode(m_pObj);
    }

    inline char *VERSION() {
      return (char*)IPWorksZip_Tar_Get(m_pObj, 0, 0, 0);
    }

  public: //properties

    inline char* GetArchiveFile() {
      void* val = IPWorksZip_Tar_Get(m_pObj, 1, 0, 0);
      return (char*)val;
    }

    inline int SetArchiveFile(const char *lpArchiveFile) {
      return IPWorksZip_Tar_Set(m_pObj, 1, 0, (void*)lpArchiveFile, 0);
    }

    inline char* GetExcludedFiles() {
      void* val = IPWorksZip_Tar_Get(m_pObj, 2, 0, 0);
      return (char*)val;
    }

    inline int SetExcludedFiles(const char *lpExcludedFiles) {
      return IPWorksZip_Tar_Set(m_pObj, 2, 0, (void*)lpExcludedFiles, 0);
    }

    inline char* GetExtractToPath() {
      void* val = IPWorksZip_Tar_Get(m_pObj, 3, 0, 0);
      return (char*)val;
    }

    inline int SetExtractToPath(const char *lpExtractToPath) {
      return IPWorksZip_Tar_Set(m_pObj, 3, 0, (void*)lpExtractToPath, 0);
    }

    inline int GetFileCount() {
      void* val = IPWorksZip_Tar_Get(m_pObj, 4, 0, 0);
      return (int)(long)val;
    }
    inline int SetFileCount(int iFileCount) {
      void* val = (void*)IPZ64CAST(iFileCount);
      return IPWorksZip_Tar_Set(m_pObj, 4, 0, val, 0);
    }
    inline ns_int64 GetFileCompressedDate(int iFileIndex) {
      ns_int64 *pval = (ns_int64*)IPWorksZip_Tar_Get(m_pObj, 5, iFileIndex, 0);
      return *pval;
    }

    inline int SetFileCompressedDate(int iFileIndex, ns_int64 lFileCompressedDate) {
      void* val = (void*)(&lFileCompressedDate);
      return IPWorksZip_Tar_Set(m_pObj, 5, iFileIndex, val, 0);
    }

    inline char* GetFileCompressedName(int iFileIndex) {
      void* val = IPWorksZip_Tar_Get(m_pObj, 6, iFileIndex, 0);
      return (char*)val;
    }

    inline int SetFileCompressedName(int iFileIndex, const char *lpFileCompressedName) {
      return IPWorksZip_Tar_Set(m_pObj, 6, iFileIndex, (void*)lpFileCompressedName, 0);
    }

    inline ns_int64 GetFileCompressedSize(int iFileIndex) {
      ns_int64 *pval = (ns_int64*)IPWorksZip_Tar_Get(m_pObj, 7, iFileIndex, 0);
      return *pval;
    }


    inline char* GetFileDecompressedName(int iFileIndex) {
      void* val = IPWorksZip_Tar_Get(m_pObj, 8, iFileIndex, 0);
      return (char*)val;
    }

    inline int SetFileDecompressedName(int iFileIndex, const char *lpFileDecompressedName) {
      return IPWorksZip_Tar_Set(m_pObj, 8, iFileIndex, (void*)lpFileDecompressedName, 0);
    }

    inline ns_int64 GetFileDecompressedSize(int iFileIndex) {
      ns_int64 *pval = (ns_int64*)IPWorksZip_Tar_Get(m_pObj, 9, iFileIndex, 0);
      return *pval;
    }


    inline char* GetFileHardLinkName(int iFileIndex) {
      void* val = IPWorksZip_Tar_Get(m_pObj, 10, iFileIndex, 0);
      return (char*)val;
    }

    inline int SetFileHardLinkName(int iFileIndex, const char *lpFileHardLinkName) {
      return IPWorksZip_Tar_Set(m_pObj, 10, iFileIndex, (void*)lpFileHardLinkName, 0);
    }

    inline char* GetFilePermissions(int iFileIndex) {
      void* val = IPWorksZip_Tar_Get(m_pObj, 11, iFileIndex, 0);
      return (char*)val;
    }

    inline int SetFilePermissions(int iFileIndex, const char *lpFilePermissions) {
      return IPWorksZip_Tar_Set(m_pObj, 11, iFileIndex, (void*)lpFilePermissions, 0);
    }

    inline char* GetFileSymLinkName(int iFileIndex) {
      void* val = IPWorksZip_Tar_Get(m_pObj, 12, iFileIndex, 0);
      return (char*)val;
    }

    inline int SetFileSymLinkName(int iFileIndex, const char *lpFileSymLinkName) {
      return IPWorksZip_Tar_Set(m_pObj, 12, iFileIndex, (void*)lpFileSymLinkName, 0);
    }

    inline int GetOverwriteFiles() {
      void* val = IPWorksZip_Tar_Get(m_pObj, 13, 0, 0);
      return (int)(long)val;
    }
    inline int SetOverwriteFiles(int bOverwriteFiles) {
      void* val = (void*)IPZ64CAST(bOverwriteFiles);
      return IPWorksZip_Tar_Set(m_pObj, 13, 0, val, 0);
    }
    inline int GetRecurseSubdirectories() {
      void* val = IPWorksZip_Tar_Get(m_pObj, 14, 0, 0);
      return (int)(long)val;
    }
    inline int SetRecurseSubdirectories(int bRecurseSubdirectories) {
      void* val = (void*)IPZ64CAST(bRecurseSubdirectories);
      return IPWorksZip_Tar_Set(m_pObj, 14, 0, val, 0);
    }
    inline int GetUseGzipCompression() {
      void* val = IPWorksZip_Tar_Get(m_pObj, 15, 0, 0);
      return (int)(long)val;
    }
    inline int SetUseGzipCompression(int bUseGzipCompression) {
      void* val = (void*)IPZ64CAST(bUseGzipCompression);
      return IPWorksZip_Tar_Set(m_pObj, 15, 0, val, 0);
    }

  public: //methods

    inline int Abort() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Tar_Do(m_pObj, 2, 0, param, cbparam);
      
      
    }
    inline int Append(const char* lpszDecompressedName, const char* lpszCompressedName) {
      void *param[2+1] = {(void*)IPZ64CAST(lpszDecompressedName), (void*)IPZ64CAST(lpszCompressedName), 0};
      int cbparam[2+1] = {0, 0, 0};
      return IPWorksZip_Tar_Do(m_pObj, 3, 2, param, cbparam);
      
      
    }
    inline int Compress() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Tar_Do(m_pObj, 4, 0, param, cbparam);
      
      
    }
    inline char* Config(const char* lpszConfigurationString) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszConfigurationString), 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_Tar_Do(m_pObj, 5, 1, param, cbparam);
      
      return (char*)param[1];
    }
    inline int Delete(const char* lpszFilenames) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszFilenames), 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Tar_Do(m_pObj, 6, 1, param, cbparam);
      
      
    }
    inline int Extract(const char* lpszFilenames) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszFilenames), 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Tar_Do(m_pObj, 7, 1, param, cbparam);
      
      
    }
    inline int ExtractAll() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Tar_Do(m_pObj, 8, 0, param, cbparam);
      
      
    }
    inline int IncludeFiles(const char* lpszfilenames) {
      void *param[1+1] = {(void*)IPZ64CAST(lpszfilenames), 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Tar_Do(m_pObj, 9, 1, param, cbparam);
      
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Tar_Do(m_pObj, 10, 0, param, cbparam);
      
      
    }
    inline int Scan() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Tar_Do(m_pObj, 11, 0, param, cbparam);
      
      
    }

};


#ifdef WIN32 //UNICODE

typedef struct {
  int Index;
  int Skip;
  int reserved;
} TarBeginFileEventParamsW;

typedef struct {
  int Index;
  int reserved;
} TarEndFileEventParamsW;

typedef struct {
  LPWSTR Description;
  int ErrorCode;
  int Index;
  LPWSTR Filename;
  int Ignore;
  int reserved;
} TarErrorEventParamsW;

typedef struct {
  LPWSTR Filename;
  int Overwrite;
  int reserved;
} TarOverwriteEventParamsW;

typedef struct {
  LPWSTR Data;
  LPWSTR Filename;
  ns_int64 *pBytesProcessed;
  int PercentProcessed;
  int lenData;
  int reserved;
} TarProgressEventParamsW;



class TarW : public Tar {

  public: //properties
  
    inline LPWSTR GetArchiveFile() {
      return (LPWSTR)IPWorksZip_Tar_Get(m_pObj, 10000+1, 0, 0);
    }

    inline int SetArchiveFile(LPWSTR lpArchiveFile) {
      return IPWorksZip_Tar_Set(m_pObj, 10000+1, 0, (void*)lpArchiveFile, 0);
    }

    inline LPWSTR GetExcludedFiles() {
      return (LPWSTR)IPWorksZip_Tar_Get(m_pObj, 10000+2, 0, 0);
    }

    inline int SetExcludedFiles(LPWSTR lpExcludedFiles) {
      return IPWorksZip_Tar_Set(m_pObj, 10000+2, 0, (void*)lpExcludedFiles, 0);
    }

    inline LPWSTR GetExtractToPath() {
      return (LPWSTR)IPWorksZip_Tar_Get(m_pObj, 10000+3, 0, 0);
    }

    inline int SetExtractToPath(LPWSTR lpExtractToPath) {
      return IPWorksZip_Tar_Set(m_pObj, 10000+3, 0, (void*)lpExtractToPath, 0);
    }





    inline LPWSTR GetFileCompressedName(int iFileIndex) {
      return (LPWSTR)IPWorksZip_Tar_Get(m_pObj, 10000+6, iFileIndex, 0);
    }

    inline int SetFileCompressedName(int iFileIndex, LPWSTR lpFileCompressedName) {
      return IPWorksZip_Tar_Set(m_pObj, 10000+6, iFileIndex, (void*)lpFileCompressedName, 0);
    }



    inline LPWSTR GetFileDecompressedName(int iFileIndex) {
      return (LPWSTR)IPWorksZip_Tar_Get(m_pObj, 10000+8, iFileIndex, 0);
    }

    inline int SetFileDecompressedName(int iFileIndex, LPWSTR lpFileDecompressedName) {
      return IPWorksZip_Tar_Set(m_pObj, 10000+8, iFileIndex, (void*)lpFileDecompressedName, 0);
    }



    inline LPWSTR GetFileHardLinkName(int iFileIndex) {
      return (LPWSTR)IPWorksZip_Tar_Get(m_pObj, 10000+10, iFileIndex, 0);
    }

    inline int SetFileHardLinkName(int iFileIndex, LPWSTR lpFileHardLinkName) {
      return IPWorksZip_Tar_Set(m_pObj, 10000+10, iFileIndex, (void*)lpFileHardLinkName, 0);
    }

    inline LPWSTR GetFilePermissions(int iFileIndex) {
      return (LPWSTR)IPWorksZip_Tar_Get(m_pObj, 10000+11, iFileIndex, 0);
    }

    inline int SetFilePermissions(int iFileIndex, LPWSTR lpFilePermissions) {
      return IPWorksZip_Tar_Set(m_pObj, 10000+11, iFileIndex, (void*)lpFilePermissions, 0);
    }

    inline LPWSTR GetFileSymLinkName(int iFileIndex) {
      return (LPWSTR)IPWorksZip_Tar_Get(m_pObj, 10000+12, iFileIndex, 0);
    }

    inline int SetFileSymLinkName(int iFileIndex, LPWSTR lpFileSymLinkName) {
      return IPWorksZip_Tar_Set(m_pObj, 10000+12, iFileIndex, (void*)lpFileSymLinkName, 0);
    }









  public: //events
  
    virtual int FireBeginFile(TarBeginFileEventParamsW *e) {return 0;}
    virtual int FireEndFile(TarEndFileEventParamsW *e) {return 0;}
    virtual int FireError(TarErrorEventParamsW *e) {return 0;}
    virtual int FireOverwrite(TarOverwriteEventParamsW *e) {return 0;}
    virtual int FireProgress(TarProgressEventParamsW *e) {return 0;}


  protected:
  
    virtual int TarEventSinkW(int event_id, int cparam, void *param[], int cbparam[]) {
    	int ret_code = 0;
      switch (event_id) {
         case 1: {
            TarBeginFileEventParamsW e = {(int)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = FireBeginFile(&e);
            param[1] = (void*)(e.Skip);
            break;
         }
         case 2: {
            TarEndFileEventParamsW e = {(int)IPZ64CAST(param[0]),  0};
            ret_code = FireEndFile(&e);
            break;
         }
         case 3: {
            TarErrorEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]), (int)IPZ64CAST(param[2]), (LPWSTR)IPZ64CAST(param[3]), (int)IPZ64CAST(param[4]),  0};
            ret_code = FireError(&e);
            param[4] = (void*)(e.Ignore);
            break;
         }
         case 4: {
            TarOverwriteEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (int)IPZ64CAST(param[1]),  0};
            ret_code = FireOverwrite(&e);
            param[0] = (void*)(e.Filename);
            param[1] = (void*)(e.Overwrite);
            break;
         }
         case 5: {
            TarProgressEventParamsW e = {(LPWSTR)IPZ64CAST(param[0]), (LPWSTR)IPZ64CAST(param[1]), (ns_int64*)IPZ64CAST(param[2]), (int)IPZ64CAST(param[3]), (int)IPZ64CAST(cbparam[0]),  0};
            ret_code = FireProgress(&e);
            break;
         }

      }
      return ret_code;
    }
  
  public: //event overrides

    virtual int FireBeginFile(TarBeginFileEventParams *e) {return -10000;}
    virtual int FireEndFile(TarEndFileEventParams *e) {return -10000;}
    virtual int FireError(TarErrorEventParams *e) {return -10000;}
    virtual int FireOverwrite(TarOverwriteEventParams *e) {return -10000;}
    virtual int FireProgress(TarProgressEventParams *e) {return -10000;}

  public: //methods

    inline int Abort() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Tar_Do(m_pObj, 10000+2, 0, param, cbparam);
      
    }
    inline int Append(LPWSTR lpszDecompressedName, LPWSTR lpszCompressedName) {
      void *param[2+1] = {(void*)lpszDecompressedName, (void*)lpszCompressedName, 0};
      int cbparam[2+1] = {0, 0, 0};
      return IPWorksZip_Tar_Do(m_pObj, 10000+3, 2, param, cbparam);
      
    }
    inline int Compress() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Tar_Do(m_pObj, 10000+4, 0, param, cbparam);
      
    }
    inline LPWSTR Config(LPWSTR lpszConfigurationString) {
      void *param[1+1] = {(void*)lpszConfigurationString, 0};
      int cbparam[1+1] = {0, 0};
      IPWorksZip_Tar_Do(m_pObj, 10000+5, 1, param, cbparam);
      return (LPWSTR)param[1];
    }
    inline int Delete(LPWSTR lpszFilenames) {
      void *param[1+1] = {(void*)lpszFilenames, 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Tar_Do(m_pObj, 10000+6, 1, param, cbparam);
      
    }
    inline int Extract(LPWSTR lpszFilenames) {
      void *param[1+1] = {(void*)lpszFilenames, 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Tar_Do(m_pObj, 10000+7, 1, param, cbparam);
      
    }
    inline int ExtractAll() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Tar_Do(m_pObj, 10000+8, 0, param, cbparam);
      
    }
    inline int IncludeFiles(LPWSTR lpszfilenames) {
      void *param[1+1] = {(void*)lpszfilenames, 0};
      int cbparam[1+1] = {0, 0};
      return IPWorksZip_Tar_Do(m_pObj, 10000+9, 1, param, cbparam);
      
    }
    inline int Reset() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Tar_Do(m_pObj, 10000+10, 0, param, cbparam);
      
    }
    inline int Scan() {
      void *param[0+1] = {0};
      int cbparam[0+1] = {0};
      return IPWorksZip_Tar_Do(m_pObj, 10000+11, 0, param, cbparam);
      
    }

};

#endif //WIN32

#endif //_IPWORKSZIP_TAR_H_




